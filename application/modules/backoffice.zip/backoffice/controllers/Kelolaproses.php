<?php

require_once ('Icontroll.php');

require 'vendor/autoload.php';
use PhpOffice\PhpWord\PhpWord;
use PhpOffice\PhpWord\Writer\Word2007;
use PhpOffice\PhpWord\TemplateProcessor;

//require_once APPPATH . 'third_party/PhpWord/TemplateProcessor.php';
/**
 * @author akil
 * @version 1.0
 * @created 26-Mar-2016 19:15:02
 */
class KelolaProses extends MX_Controller implements IControll {

    function __construct() {
        parent::__construct();
        $this->load->library('sessionutility');
        if (!$this->sessionutility->validateSession()) {
            redirect(base_url() . 'backoffice/');
        }
        $this->load->model('proses');
        $this->load->model('registrasi');
        $this->load->model('account');
        $this->load->model('pti');
        $this->load->model('verifikasi');
        $this->load->model('periode');
        $this->load->model('dokumenperbaikan');
        $this->load->model('dokumenperbaikanupload');
        $this->load->model('rekapitulasiberitaacara');
        $this->load->model('jenisusulan');
        $this->load->helper('download');
    }

    function __destruct() {
        
    }

    public function add() {
        
    }

    public function edit() {
        
    }

    public function find() {
        $view = 'list_proses';

        $id_registrasi = trim($this->input->post('id_registrasi'));
        $yayasan = trim($this->input->post('yayasan'));
        $pti = trim($this->input->post('pti'));
        $jns_usulan = trim($this->input->post('jns_usulan'));
        $evaluator = trim($this->input->post('evaluator'));        
        $status_proses = trim($this->input->post('status_proses'));
        

        $segment = $this->uri->segment(4, 0);
        $temp_post = $this->input->post(NULL, TRUE);
        if (!$temp_post) {
            $id_registrasi = trim($this->session->flashdata('id_registrasi'));
            $yayasan = trim($this->session->flashdata('yayasan'));
            $pti = trim($this->session->flashdata('pti'));
            $jns_usulan = trim($this->session->flashdata('jns_usulan'));
            $evaluator = trim($this->session->flashdata('evaluator'));
            $status_proses = trim($this->session->flashdata('status_proses'));            
        }
        $temp_filter = array(
            'id_registrasi' => $id_registrasi,
            'yayasan' => $yayasan,
            'pti' => $pti,
            'jns_usulan' => $jns_usulan,
            'evaluator' => $evaluator,            
            'status_proses' => $status_proses            
        );
        $this->session->set_flashdata($temp_filter);

        $proses = new Proses();
        $periode = new Periode();
        $periode->getBy('status_periode', 'open');                
        $current_periode = $periode->getOpenPeriode();
        //print_r($current_periode);
        $proses->setPeriode($current_periode[0]);

        if ($this->input->post('export')) {
            $params = array(
                'paging' => array('row' => '0', 'segment' => '0')
            );
        } else {
            $params = array(
                'paging' => array('row' => 10, 'segment' => $segment)
            );
        }
        $params['field']['registrasi.periode'] = $current_periode[0];
        if ($id_registrasi != '') {
            $params['field']['registrasi.id_registrasi'] = $id_registrasi;
        }
        if ($yayasan != '') {
            $params['join']['tbl_badan_penyelenggara'] = 'registrasi.kdpti = tbl_badan_penyelenggara.kdpti';
            $params['field']['tbl_badan_penyelenggara.nama_penyelenggara'] = $yayasan;
        }
        if ($pti != '') {
            $params['join']['tbl_pti'] = 'registrasi.kdpti = tbl_pti.kdpti';
            $params['field']['tbl_pti.nmpti'] = $pti;
        }
        if ($jns_usulan != '') {
            $params['field']['registrasi.jns_usulan'] = $jns_usulan;
        }
        if ($evaluator != '') {
            $params['join']['evaluator'] = "proses.id_evaluator = evaluator.id_evaluator";
            $params['field']['evaluator.nm_evaluator'] = $evaluator;
        }
        
        if ($status_proses != '') {
            $params['join']['status_proses'] = "proses.id_status_proses = status_proses.id_status_proses";
            $params['field']['status_proses.id_status_proses'] = $status_proses;
        }
        
        $user = new ModUsers($this->session->userdata('userid'));
        if($user->getIdEvaluator()!=''){
            $params['field']['proses.id_evaluator'] = $user->getIdEvaluator();
            $params['field']['proses.id_status_proses'] = array('1','2');
        }
        
        $result_proses = $proses->search($params);

        //config pagination                     
        $per_page = 10;
        $params['count'] = array('1');
        $total_row = $proses->search($params);
        $base_url = base_url() . 'backoffice/kelolaproses/find/';
        setPagingTemplate($base_url, 4, $total_row, $per_page);

        //data jns_usulan
        $this->db->select('*');
        $this->db->from('jenis_usulan');
        $res_jns_usulan = $this->db->get();
        $option_jns_usulan = array('' => '~Pilih~');
        foreach ($res_jns_usulan->result() as $value) {
            $option_jns_usulan[$value->jns_usulan] = $value->nm_usulan;
        }
        
        //data status
        $obj_status_proses = new StatusProses();
        $result_status = $obj_status_proses->get('0', '0');
        $option_status = array('' => '~Pilih~');
        foreach ($result_status->result() as $value) {
            $option_status[$value->id_status_proses] = $value->nama_status;
        }
        $data['status_proses'] = $option_status;
        $data['jns_usulan'] = $option_jns_usulan;
        $data['proses'] = $result_proses;
        $data['total_row'] = $total_row;
        
        if ($this->input->post('export')) {
            $this->load->view('export_proses', $data);
            //print_r($result);
        } else {
            showBackEnd($view, $data, 'index_new');
        }
    }

    public function index() {
        $view = 'list_proses';

        $proses = new Proses();
        $segment = $this->uri->segment(4, 0);
        $per_page = 10;
        $periode = new Periode();
        $periode->getBy('status_periode', 'open');                
        $current_periode = $periode->getOpenPeriode();
        //print_r($current_periode);
        $proses->setPeriode($current_periode[0]);

        $params = array(
            'paging' => array('row' => 10, 'segment' => $segment)
        );
        $params['field']['registrasi.periode'] = $current_periode[0];
        $result = $proses->search($params);
        $params['count'] = array('1');
        $total_row = $proses->search($params);
        $base_url = base_url() . 'backoffice/kelolaproses/index';
        setPagingTemplate($base_url, 4, $total_row, $per_page);

        //data status
        $status_proses = new StatusProses();
        $result_status = $status_proses->get('0', '0');
        $option_status = array('' => '~Pilih~');
        foreach ($result_status->result() as $value) {
            $option_status[$value->id_status_proses] = $value->nama_status;
        }

        //data jns_usulan
        $this->db->select('*');
        $this->db->from('jenis_usulan');
        $res_jns_usulan = $this->db->get();
        $option_jns_usulan = array('' => '~Pilih~');
        foreach ($res_jns_usulan->result() as $value) {
            $option_jns_usulan[$value->jns_usulan] = $value->nm_usulan;
        }
        $data['jns_usulan'] = $option_jns_usulan;
        $data['status_proses'] = $option_status;
        $data['proses'] = $result;
        $data['total_row'] = $total_row;
        showBackEnd($view, $data, 'index_new');
    }

    public function remove() {
        
    }

    public function save() {
        
    }

    public function indexEvaluator() {
        $view = 'list_proses';

        $proses = new Proses();
        $segment = $this->uri->segment(4, 0);
        $per_page = 10;
        $periode = new Periode();
        $periode->getBy('status_periode', 'open');                
        $current_periode = $periode->getOpenPeriode();
        //$proses->setPeriode($current_periode);
        
        $params = array(
            'paging' => array('row' => 10, 'segment' => $segment)
        );
        $params['field']['registrasi.periode'] = $current_periode[0];
        $params['field']['proses.id_status_proses'] = array('1','2');
        $user = new ModUsers($this->session->userdata('userid'));
        if($user->getIdEvaluator()!=''){
            $params['field']['id_evaluator'] = $user->getIdEvaluator();
        }
        $result = $proses->search($params);
        $params['count'] = array('1');
        $total_row = $proses->search($params);
        $base_url = base_url() . 'backoffice/kelolaproses/indexevaluator';
        setPagingTemplate($base_url, 4, $total_row, $per_page);

        //data status
        $status_proses = new StatusProses();
        $result_status = $status_proses->get('0', '0');
        $option_status = array('' => '~Pilih~');
        foreach ($result_status->result() as $value) {
            $option_status[$value->id_status_proses] = $value->nama_status;
        }

        //data jns_usulan
        $this->db->select('*');
        $this->db->from('jenis_usulan');
        $res_jns_usulan = $this->db->get();
        $option_jns_usulan = array('' => '~Pilih~');
        foreach ($res_jns_usulan->result() as $value) {
            $option_jns_usulan[$value->jns_usulan] = $value->nm_usulan;
        }
        $data['jns_usulan'] = $option_jns_usulan;
        $data['status_proses'] = $option_status;
        $data['proses'] = $result;
        $data['total_row'] = $total_row;
        add_footer_css('jquery-ui-1.12.1/jquery-ui.css');
        add_footer_js('jquery-ui-1.12.1/jquery-ui.js');
        showBackEnd($view, $data, 'index_new');
    }

    public function downloadInstrument() {
        //if($this->sessionutility->validateAccess($this)){
        //$this->load->library('zip');
        $id_proses = $this->uri->segment(4, 0);
        $proses = new Proses($id_proses);
        $registrasi = $proses->getRegistrasi(); //new Registrasi($id_reg);
        //$proses = $registrasi->getProses();
        $eval = $this->session->userdata('userid');
        //$account = $registrasi->getAccount();
        //$yayasan = $account->getYayasan();
        $pt = $registrasi->getPti();
        //$status = $registrasi->getStatusRegistrasi();
        $schema = $registrasi->getSchema();
        $filepath = '';
        /* if($schema=='C'){
          $filepath = realpath(APPPATH . '../assets/documents/template_penilaian_2019.xlsx');
          }elseif($schema=='B' || $schema=='A'){
          $filepath = realpath(APPPATH . '../assets/documents/template_penilaian_skema_b.xlsx');
          } */
        $filepath = realpath(APPPATH . '../assets/documents/template_penilaian_2021.xlsx');

        $name = $registrasi->getIdRegistrasi() . '_' . str_replace(' ', '_', $pt->getNmPti()) . '_' . $eval . '.xlsx';
        //$archive = realpath(APPPATH . '../assets/documents/');
        if (is_file($filepath)) {
            $proses->setIdStatusProses('2'); //proses penilaian
            $proses->setTglTerima(date('Y-m-d'));
            $proses->update();
            $registrasi->setIdStatusRegistrasi('3'); //evaluasi
            $registrasi->update();
            $data = file_get_contents($filepath);
            force_download($name, $data);
        } else {
            echo '<script type="text/javascript">';
            echo 'alert("Gagal membuka file, atau instrumen tidak tersedia!");';
            echo 'window.history.back(1)';
            echo '</script>';
        }
        /* }else{
          echo '<script>';
          echo 'alert("Validation Fail !");';
          echo 'window.history.back(1);';
          echo '</script>';
          } */
    }

    public function detailDocument($id_reg) {
        $view = 'detail_registrasi';
        $registrasi = new Registrasi($id_reg);
        $data['registrasi'] = $registrasi;
        showBackEnd($view, $data, 'index_new');
    }

    public function getLinkMonitoring() {

        $id_proses = $this->uri->segment(4, 0);
        $kdpti = $this->uri->segment(5, 0);
        //$user = $this->session->userdata('userid');
        $proses = new Proses($id_proses);
        $proses->setIdStatusProses('2'); //proses penilaian
        $proses->setTglTerima(date('Y-m-d'));
        $proses->update();

        $registrasi = $proses->getRegistrasi();
        $status = array('7', '9');
        if (!in_array($registrasi->getIdStatusRegistrasi(), $status)) {
            $registrasi->setIdStatusRegistrasi('4'); //presentasi
            $registrasi->update();
        }

        $base_url = 'http://pppts.kemdikbud.go.id/'; //base_url();
        $url_monitoring = $base_url . 'site/alias-login-detail-usulan?id=' . $kdpti . '&admin=idc&id_registrasi=' . $registrasi->getIdRegistrasi();
        //$url_monitoring = $base_url.'registrasi/detail?id='.$registrasi->getIdRegistrasi();
        //echo 'url: '.$url_monitoring;
        redirect($url_monitoring);
    }

    public function getLinkBeritaAcara() {

        $id_proses = $this->uri->segment(4, 0);
        $kdpti = $this->uri->segment(5, 0);
        //$user = $this->session->userdata('userid');
        $proses = new Proses($id_proses);
        $proses->setIdStatusProses('2'); //proses penilaian
        $proses->setTglTerima(date('Y-m-d'));
        //$proses->update();

        $registrasi = $proses->getRegistrasi();
        $registrasi->setIdStatusRegistrasi('4'); //presentasi
        //$registrasi->update();
        $base_url = 'http://pppts.kemdikbud.go.id/'; //base_url();
        $url_monitoring = $base_url . 'download/berita-acara?id=' . $registrasi->getIdRegistrasi();
        redirect($url_monitoring);
    }

    public function getLinkBeritaAcaraFinal() {

        $id_proses = $this->uri->segment(4, 0);
        $kdpti = $this->uri->segment(5, 0);
        //$user = $this->session->userdata('userid');
        $proses = new Proses($id_proses);
        $proses->setIdStatusProses('2'); //proses penilaian
        $proses->setTglTerima(date('Y-m-d'));
        //$proses->update();

        $registrasi = $proses->getRegistrasi();
        $registrasi->setIdStatusRegistrasi('4'); //presentasi
        //$registrasi->update();
        $base_url = 'http://pppts.kemdikbud.go.id/'; //base_url();
        $url_monitoring = $base_url . 'download/berita-acara?id=' . $registrasi->getIdRegistrasi();
        redirect($url_monitoring);
    }

    public function getBeritaAcaraFinal() {
        $id_registrasi = $this->uri->segment(4);
        $registrasi = new Registrasi($id_registrasi);
        $jns_usulan = $registrasi->getJnsUsulan();
        
        $dokumen_template = '';
        $qry = "SELECT * FROM tbl_direktorat_aktif WHERE status='Aktif'";
        $res_query = $this->db->query($qry);
        if($res_query->num_rows()>0){
            $row = $res_query->row();
            /*if($row->nama_direktorat=='Akademik'){
                if($jns_usulan=='01' || $jns_usulan=='03'){//barang
                    $dokumen_template = './assets/documents/akademik/Format_Berita_Acara_Hasil_Final_Barang_dan_Gedung.docx';
                }elseif($jns_usulan=='02'){//gedung
                    $dokumen_template = './assets/documents/akademik/Format_Berita_Acara_Hasil_Final_Gedung.docx';
                }
            }else{*/
                if($jns_usulan=='01' || $jns_usulan=='03'){//barang
                    $dokumen_template = './assets/documents/vokasi/Format_Berita_Acara_Hasil_Final_Barang_dan_Gedung.docx';
                }elseif($jns_usulan=='02'){//gedung
                    $dokumen_template = './assets/documents/vokasi/Format_Berita_Acara_Hasil_Final_Gedung.docx';
                }
                
           //}
        }
        
        if (is_file($dokumen_template)) {
            $templateProcessor = new TemplateProcessor($dokumen_template);
        } else {
            exit("File not found!");
        }
        
        $yys = $registrasi->getPenyelenggara();
        $nama_yys = $yys->getNamaPenyelenggara();
        $pti = $registrasi->getPti();
        $nama_pt = $pti->getNmPti();
        $reviewer = '';
        $t_teknis = '';
        $result_proses = $registrasi->getProses2();
        foreach ($result_proses as $obj) {
            if ($obj->getTypeEvaluator() == '1') {
                $evaluator = $obj->getEvaluator();
                $reviewer = $evaluator->getNmEvaluator();
            } elseif ($obj->getTypeEvaluator() == '2') {
                $evaluator = $obj->getEvaluator();
                $t_teknis = $evaluator->getNmEvaluator();
            }
        }
        $lab_ipa = 0;
        $lab_kes = 0;
        $lab_teknik = 0;
        $lab_micro = 0;
        $lab_bahasa = 0;
        $alat_ti = 0;
        $kelas = 0;
        $laboratorium = 0;
        $total = 0;
        if($jns_usulan=='01' || $jns_usulan=='03'){//barang
            $query = "SELECT
            ti.kd_sub2_kategori,ti.nm_sub2_kategori,
            IF (harga_satuan > 1, '1', '-') AS paket,
             harga_satuan,
             jumlah_biaya
            FROM
                    tbl_item_sub2kategori ti
            JOIN tbl_item_subkategori c ON ti.kd_sub_kategori = c.kd_sub_kategori
            LEFT JOIN (
                    SELECT
                            SUM(
                                    a.subtotal - (a.ongkir_satuan * a.jml_item)
                            ) AS harga_satuan,
                            SUM(a.subtotal) AS jumlah_biaya,
                            b.kd_barang
                    FROM
                            tbl_item_hibah a
                    JOIN tbl_item_barang b ON a.id_item = b.id_item
                    WHERE
                            id_registrasi = '" . $id_registrasi . "'
                    GROUP BY
                            LEFT (a.id_item, 6)
            ) AS a ON ti.kd_sub2_kategori = LEFT (a.kd_barang, 6)
            WHERE
                    c.skema = 'A'";

            $result = $this->db->query($query);
            //print_r($result->result());
            foreach ($result->result() as $row) {
                if ($row->kd_sub2_kategori == '013501') {
                    $ppn = ($row->jumlah_biaya * 10) / 100;
                    $lab_teknik = $row->jumlah_biaya + $ppn;
                }
                if ($row->kd_sub2_kategori == '013601') {
                    $ppn = ($row->jumlah_biaya * 10) / 100;
                    $alat_ti = $row->jumlah_biaya + $ppn;
                }
                if ($row->kd_sub2_kategori == '013101') {
                    $ppn = ($row->jumlah_biaya * 10) / 100;
                    $lab_ipa = $row->jumlah_biaya + $ppn;
                }
                if ($row->kd_sub2_kategori == '013201') {
                    $ppn = ($row->jumlah_biaya * 10) / 100;
                    $lab_bahasa = $row->jumlah_biaya + $ppn;
                }
                if ($row->kd_sub2_kategori == '013301') {
                    $ppn = ($row->jumlah_biaya * 10) / 100;
                    $lab_kes = $row->jumlah_biaya + $ppn;
                }
                if ($row->kd_sub2_kategori == '013401') {
                    $ppn = ($row->jumlah_biaya * 10) / 100;
                    $lab_micro = $row->jumlah_biaya + $ppn;
                }
                if ($row->kd_sub2_kategori == '020501') {
                    $ppn = ($row->jumlah_biaya * 10) / 100;
                    $kelas = $row->jumlah_biaya;
                }
                if ($row->kd_sub2_kategori == '020601') {
                    $ppn = ($row->jumlah_biaya * 10) / 100;
                    $laboratorium = $row->jumlah_biaya;
                }
            }
            
            //$ppn = ($total * 10)/100;
            //$temp_total_ppn = $total + $ppn ;
            
            $templateProcessor->setValue('lab_ipa', number_format($lab_ipa, 2));
            $templateProcessor->setValue('lab_kes', number_format($lab_kes, 2));
            $templateProcessor->setValue('lab_teknik', number_format($lab_teknik, 2));
            $templateProcessor->setValue('lab_micro', number_format($lab_micro, 2));
            $templateProcessor->setValue('lab_bahasa', number_format($lab_bahasa, 2));
            $templateProcessor->setValue('alat_ti', number_format($alat_ti, 2));
            $templateProcessor->setValue('kelas', number_format($kelas, 2));
            $templateProcessor->setValue('laboratorium', number_format($laboratorium, 2));
            
            $templateProcessor->setValue('yys', $nama_yys);
            $templateProcessor->setValue('pt', $nama_pt);
            $templateProcessor->setValue('reviewer', $reviewer);
            $templateProcessor->setValue('t_teknis', $t_teknis);
            $templateProcessor->setValue('dd', date('d'));
            $templateProcessor->setValue('mm', date('F'));
            $templateProcessor->setValue('yyyy', date('Y'));
            //bagian gedung
            $qry = "SELECT a.id_item,SUM(a.subtotal) AS jumlah_biaya 
            FROM tbl_item_hibah a
            JOIN tbl_item_gedung b ON a.id_item = b.kd_gedung
            WHERE id_registrasi = '".$id_registrasi."'
            GROUP BY a.id_item";
            $result2 = $this->db->query($qry);
            if($result2->num_rows()>0){
                foreach ($result2->result() as $row) {
                    if($row->id_item = '020501'){//kelas
                        $kelas = $row->jumlah_biaya;
                    }else{
                        $laboratorium = $row->jumlah_biaya;
                    }
                    $total = $total + $row->jumlah_biaya;
                }
                $templateProcessor->setValue('kelas', number_format($kelas, 2));
                $templateProcessor->setValue('laboratorium', number_format($laboratorium, 2));
                //$templateProcessor->setValue('total', $total);
            }
            $total = ($lab_ipa + $lab_kes + $lab_teknik + $lab_micro + $lab_bahasa + $alat_ti + $kelas + $laboratorium);
            $total_ppn = number_format($total, 2);
            $templateProcessor->setValue('total', $total_ppn);
        }elseif($jns_usulan=='02'){
            $qry = "SELECT a.id_item,SUM(a.subtotal) AS jumlah_biaya 
            FROM tbl_item_hibah a
            JOIN tbl_item_gedung b ON a.id_item = b.kd_gedung
            WHERE id_registrasi = '".$id_registrasi."'
            GROUP BY a.id_item";
            $result = $this->db->query($qry);
            if($result->num_rows()>0){
                foreach ($result->result() as $row) {
                    if($row->id_item == '020501'){//kelas
                        $kelas = $row->jumlah_biaya;
                    }elseif($row->id_item == '020601'){
                        $laboratorium = $row->jumlah_biaya;
                    }
                    $total = $total + $row->jumlah_biaya;
                }
                $templateProcessor->setValue('yys', $nama_yys);
                $templateProcessor->setValue('pt', $nama_pt);
                $templateProcessor->setValue('reviewer', $reviewer);
                $templateProcessor->setValue('t_teknis', $t_teknis);
                $templateProcessor->setValue('kelas', number_format($kelas, 2));
                $templateProcessor->setValue('laboratorium', number_format($laboratorium, 2));
                $templateProcessor->setValue('total', number_format($total,2));
                $templateProcessor->setValue('dd', date('d'));
                $templateProcessor->setValue('mm', date('F'));
                $templateProcessor->setValue('yyyy', date('Y'));
            }
        }
        $filename = $id_registrasi . '_' . str_replace(' ', '_', $nama_pt) . '_berita_acara_final.docx';

        header('Content-Type: application/msword');
        header('Content-Disposition: attachment;filename="' . $filename . '"');
        header('Cache-Control: max-age=0');
        $templateProcessor->saveAs('php://output');
    }

    public function getDraftBeritaAcara() {
        $id_registrasi = $this->uri->segment(4);
        $registrasi = new Registrasi($id_registrasi);
        $jns_usulan = $registrasi->getJnsUsulan();
        
        $dokumen_template = '';
        $qry = "SELECT * FROM tbl_direktorat_aktif WHERE status='Aktif'";
        $res_query = $this->db->query($qry);
        if($res_query->num_rows()>0){
            $row = $res_query->row();
            /*if($row->nama_direktorat=='Akademik'){
                if($jns_usulan=='01' || $jns_usulan=='03'){//barang
                    $dokumen_template = './assets/documents/akademik/Format_Draf_Berita_Acara_Barang_dan_Gedung.docx';
                }elseif($jns_usulan=='02'){//gedung
                    $dokumen_template = './assets/documents/akademik/Format_Draf_Berita_Acara_Gedung.docx';
                }
            }else{*/
                if($jns_usulan=='01' || $jns_usulan=='03'){//barang
                    $dokumen_template = './assets/documents/vokasi/Format_Draf_Berita_Acara_Barang_dan_Gedung.docx';
                }elseif($jns_usulan=='02'){//gedung
                    $dokumen_template = './assets/documents/vokasi/Format_Draf_Berita_Acara_Gedung.docx';
                }
                
            //}
        }
        
        if (is_file($dokumen_template)) {
            $templateProcessor = new TemplateProcessor($dokumen_template);
        } else {
            exit("File not found!");
        }
        
        $yys = $registrasi->getPenyelenggara();
        $nama_yys = $yys->getNamaPenyelenggara();
        $pti = $registrasi->getPti();
        $nama_pt = $pti->getNmPti();
        $reviewer = '';
        $t_teknis = '';
        $result_proses = $registrasi->getProses2();
        foreach ($result_proses as $obj) {
            if ($obj->getTypeEvaluator() == '1') {
                $evaluator = $obj->getEvaluator();
                $reviewer = $evaluator->getNmEvaluator();
            } elseif ($obj->getTypeEvaluator() == '2') {
                $evaluator = $obj->getEvaluator();
                $t_teknis = $evaluator->getNmEvaluator();
            }
        }
        $lab_ipa = 0;
        $lab_kes = 0;
        $lab_teknik = 0;
        $lab_micro = 0;
        $lab_bahasa = 0;
        $alat_ti = 0;
        $kelas = 0;
        $laboratorium = 0;
        $total = 0;
        if($jns_usulan=='01' || $jns_usulan=='03'){//barang
            $query = "SELECT
            ti.kd_sub2_kategori,ti.nm_sub2_kategori,
            IF (harga_satuan > 1, '1', '-') AS paket,
             harga_satuan,
             jumlah_biaya
            FROM
                    tbl_item_sub2kategori ti
            JOIN tbl_item_subkategori c ON ti.kd_sub_kategori = c.kd_sub_kategori
            LEFT JOIN (
                    SELECT
                            SUM(
                                    a.subtotal - (a.ongkir_satuan * a.jml_item)
                            ) AS harga_satuan,
                            SUM(a.subtotal) AS jumlah_biaya,
                            b.kd_barang
                    FROM
                            tbl_item_hibah a
                    JOIN tbl_item_barang b ON a.id_item = b.id_item
                    WHERE
                            id_registrasi = '" . $id_registrasi . "'
                    GROUP BY
                            LEFT (a.id_item, 6)
            ) AS a ON ti.kd_sub2_kategori = LEFT (a.kd_barang, 6)
            WHERE
                    c.skema = 'A'";

            $result = $this->db->query($query);
            //print_r($result->result());
            foreach ($result->result() as $row) {
                if ($row->kd_sub2_kategori == '013501') {
                    $ppn = ($row->jumlah_biaya * 10) / 100;
                    $lab_teknik = $row->jumlah_biaya + $ppn;
                }
                if ($row->kd_sub2_kategori == '013601') {
                    $ppn = ($row->jumlah_biaya * 10) / 100;
                    $alat_ti = $row->jumlah_biaya + $ppn;
                }
                if ($row->kd_sub2_kategori == '013101') {
                    $ppn = ($row->jumlah_biaya * 10) / 100;
                    $lab_ipa = $row->jumlah_biaya + $ppn;
                }
                if ($row->kd_sub2_kategori == '013201') {
                    $ppn = ($row->jumlah_biaya * 10) / 100;
                    $lab_bahasa = $row->jumlah_biaya + $ppn;
                }
                if ($row->kd_sub2_kategori == '013301') {
                    $ppn = ($row->jumlah_biaya * 10) / 100;
                    $lab_kes = $row->jumlah_biaya + $ppn;
                }
                if ($row->kd_sub2_kategori == '013401') {
                    $ppn = ($row->jumlah_biaya * 10) / 100;
                    $lab_micro = $row->jumlah_biaya + $ppn;
                }
                if ($row->kd_sub2_kategori == '020501') {
                    $ppn = ($row->jumlah_biaya * 10) / 100;
                    $kelas = $row->jumlah_biaya;
                }
                if ($row->kd_sub2_kategori == '020601') {
                    $ppn = ($row->jumlah_biaya * 10) / 100;
                    $laboratorium = $row->jumlah_biaya;
                }
            }
            
            //$ppn = ($total * 10)/100;
            //$temp_total_ppn = $total + $ppn ;
            
            $templateProcessor->setValue('lab_ipa', number_format($lab_ipa, 2));
            $templateProcessor->setValue('lab_kes', number_format($lab_kes, 2));
            $templateProcessor->setValue('lab_teknik', number_format($lab_teknik, 2));
            $templateProcessor->setValue('lab_micro', number_format($lab_micro, 2));
            $templateProcessor->setValue('lab_bahasa', number_format($lab_bahasa, 2));
            $templateProcessor->setValue('alat_ti', number_format($alat_ti, 2));
            $templateProcessor->setValue('kelas', number_format($kelas, 2));
            $templateProcessor->setValue('laboratorium', number_format($laboratorium, 2));
            
            $templateProcessor->setValue('yys', $nama_yys);
            $templateProcessor->setValue('pt', $nama_pt);
            $templateProcessor->setValue('reviewer', $reviewer);
            $templateProcessor->setValue('t_teknis', $t_teknis);
            $templateProcessor->setValue('dd', date('d'));
            $templateProcessor->setValue('mm', date('F'));
            $templateProcessor->setValue('yyyy', date('Y'));
            //bagian gedung
            $qry = "SELECT a.id_item,SUM(a.subtotal) AS jumlah_biaya 
            FROM tbl_item_hibah a
            JOIN tbl_item_gedung b ON a.id_item = b.kd_gedung
            WHERE id_registrasi = '".$id_registrasi."'
            GROUP BY a.id_item";
            $result2 = $this->db->query($qry);
            if($result2->num_rows()>0){
                foreach ($result2->result() as $row) {
                    if($row->id_item = '020501'){//kelas
                        $kelas = $row->jumlah_biaya;
                    }else{
                        $laboratorium = $row->jumlah_biaya;
                    }
                    $total = $total + $row->jumlah_biaya;
                }
                $templateProcessor->setValue('kelas', number_format($kelas, 2));
                $templateProcessor->setValue('laboratorium', number_format($laboratorium, 2));
                //$templateProcessor->setValue('total', $total);
            }
            $total = ($lab_ipa + $lab_kes + $lab_teknik + $lab_micro + $lab_bahasa + $alat_ti + $kelas + $laboratorium);
            $total_ppn = number_format($total, 2);
            $templateProcessor->setValue('total', $total_ppn);
        }elseif($jns_usulan=='02'){
            $qry = "SELECT a.id_item,SUM(a.subtotal) AS jumlah_biaya 
            FROM tbl_item_hibah a
            JOIN tbl_item_gedung b ON a.id_item = b.kd_gedung
            WHERE id_registrasi = '".$id_registrasi."'
            GROUP BY a.id_item";
            $result = $this->db->query($qry);
            if($result->num_rows()>0){
                foreach ($result->result() as $row) {
                    if($row->id_item == '020501'){//kelas
                        $kelas = $row->jumlah_biaya;
                    }elseif($row->id_item == '020601'){
                        $laboratorium = $row->jumlah_biaya;
                    }
                    $total = $total + $row->jumlah_biaya;
                }
                $templateProcessor->setValue('yys', $nama_yys);
                $templateProcessor->setValue('pt', $nama_pt);
                $templateProcessor->setValue('reviewer', $reviewer);
                $templateProcessor->setValue('t_teknis', $t_teknis);
                $templateProcessor->setValue('kelas', number_format($kelas, 2));
                $templateProcessor->setValue('laboratorium', number_format($laboratorium, 2));
                $templateProcessor->setValue('total', number_format($total,2));
                $templateProcessor->setValue('dd', date('d'));
                $templateProcessor->setValue('mm', date('F'));
                $templateProcessor->setValue('yyyy', date('Y'));
            }
        }
        $filename = $id_registrasi . '_' . str_replace(' ', '_', $nama_pt) . '_draft_berita_acara.docx';

        header('Content-Type: application/msword');
        header('Content-Disposition: attachment;filename="' . $filename . '"');
        header('Cache-Control: max-age=0');
        $templateProcessor->saveAs('php://output');
    }

    public function getPaktaKesepakatan() {
        $id_registrasi = $this->uri->segment(4);
        $registrasi = new Registrasi($id_registrasi);
        $pt = $registrasi->getPti();
        $dokumen_template = '';
        $qry = "SELECT * FROM tbl_direktorat_aktif WHERE status='Aktif'";
        $res_query = $this->db->query($qry);
        if($res_query->num_rows()>0){
            $row = $res_query->row();
            if($row->nama_direktorat=='Akademik'){
                $dokumen_template = realpath(APPPATH . '../assets/documents/akademik/Format_Pakta_Kesepakatan_Pengadaan_Barang_PP-PTS_2020.docx');
            }else{
                $dokumen_template = realpath(APPPATH . '../assets/documents/vokasi/Format_Pakta_Kesepakatan_Pengadaan_Barang_PP-PTS_2020.docx');
                
            }
        }
        
        $name = $registrasi->getIdRegistrasi() . '_' . str_replace(' ', '_', $pt->getNmPti()) . '_pakta_kesepakatan' . '.docx';

        if (is_file($dokumen_template)) {
            $templateProcessor = new TemplateProcessor($dokumen_template);
            $this->db->select('*');
            $this->db->from('jadwal_presentasi');
            $this->db->where('id_registrasi', $id_registrasi);
            $result = $this->db->get();
            if ($result->num_rows() > 0) {
                $row = $result->row();
                $templateProcessor->setValue('no_surat', $row->no_surat);
            } else {
                $templateProcessor->setValue('no_surat', '-');
            }
            header('Content-Type: application/msword');
            header('Content-Disposition: attachment;filename="' . $name . '"');
            header('Cache-Control: max-age=0');
            $templateProcessor->saveAs('php://output');
        } else {


            echo '<script type="text/javascript">';
            echo 'alert("Gagal membuka file, atau instrumen tidak tersedia!");';
            echo 'window.history.back(1)';
            echo '</script>';
        }
    }

    public function getSuratTugas() {
        $qry = "SELECT * FROM tbl_direktorat_aktif WHERE status='Aktif'";
        $res_query = $this->db->query($qry);
        $filepath = '';
        if($res_query->num_rows()>0){
            $row = $res_query->row();
            /*if($row->nama_direktorat=='Akademik'){
                $filepath = realpath(APPPATH . '../assets/documents/Format_Surat_Tugas_Penerimaan_Barang_2020.docx');
            }else{*/
                $filepath = realpath(APPPATH . '../assets/documents/vokasi/Format_Surat_Tugas_Penerimaan_Barang_PP-PTS_2020.docx');
                
            //}
        }
        
        $id_registrasi = $this->uri->segment(4);
        $registrasi = new Registrasi($id_registrasi);
        $pt = $registrasi->getPti();
        $name = $registrasi->getIdRegistrasi() . '_' . str_replace(' ', '_', $pt->getNmPti()) . '_surat_tugas' . '.docx';
        //$archive = realpath(APPPATH . '../assets/documents/');
        if (is_file($filepath)) {

            $data = file_get_contents($filepath);
            force_download($name, $data);
        } else {
            echo '<script type="text/javascript">';
            echo 'alert("Gagal membuka file, atau instrumen tidak tersedia!");';
            echo 'window.history.back(1)';
            echo '</script>';
        }
    }
    
    public function getPernyataanPersetujuan(){
        $qry = "SELECT * FROM tbl_direktorat_aktif WHERE status='Aktif'";
        $res_query = $this->db->query($qry);
        $filepath = '';
        if($res_query->num_rows()>0){
            $row = $res_query->row();
            /*if($row->nama_direktorat=='Akademik'){
                $filepath = realpath(APPPATH . '../assets/documents/vokasi/Format_Pernyataan_Persetujuan.docx');    
            }else{*/
                $filepath = realpath(APPPATH . '../assets/documents/vokasi/Format_Pernyataan_Persetujuan.docx');                
            //}
        }
        
        $id_registrasi = $this->uri->segment(4);
        $registrasi = new Registrasi($id_registrasi);
        $pt = $registrasi->getPti();
        $name = $registrasi->getIdRegistrasi() . '_' . str_replace(' ', '_', $pt->getNmPti()) . '_pernyataan_persetujuan' . '.docx';
        //$archive = realpath(APPPATH . '../assets/documents/');
        if (is_file($filepath)) {

            $data = file_get_contents($filepath);
            force_download($name, $data);
        } else {
            echo '<script type="text/javascript">';
            echo 'alert("Gagal membuka file, atau instrumen tidak tersedia!");';
            echo 'window.history.back(1)';
            echo '</script>';
        }
    }

}

?>