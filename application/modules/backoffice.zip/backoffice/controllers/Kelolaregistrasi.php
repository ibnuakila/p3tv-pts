<?php

require_once ('Icontroll.php');
require_once APPPATH . 'third_party/PHPExcel.php';
require_once APPPATH . 'third_party/PHPExcel/IOFactory.php';

/**
 * @author akil
 * @version 1.0
 * @created 26-Mar-2016 19:14:52
 */
class KelolaRegistrasi extends MX_Controller implements IControll {

    function __construct() {
        parent::__construct();
        $this->load->library('sessionutility');
        if (!$this->sessionutility->validateSession()) {
            redirect(base_url() . 'backoffice/');
        }
        $this->load->model('registrasi');
        $this->load->model('verifikasi');
        $this->load->model('periode');
        $this->load->model('dokumenperbaikan');
        $this->load->model('dokumenperbaikanupload');
        $this->load->model('rekapitulasiberitaacara');
    }

    function __destruct() {
        
    }

    public function add() {
        
    }

    public function edit() {
        
    }

    public function find() {
        if ($this->sessionutility->validateAccess($this)) {
            $view = 'list_registrasi';

            $id_registrasi = trim($this->input->post('id_registrasi'));
            $yayasan = trim($this->input->post('yayasan'));
            $pti = trim($this->input->post('pti'));
            $tgl_registrasi = trim($this->input->post('tgl_registrasi'));
            $periode = trim($this->input->post('periode'));
            $schema = trim($this->input->post('schema'));
            $status_registrasi = trim($this->input->post('status_registrasi'));
            $publish_verifikasi = trim($this->input->post('publish_verifikasi'));
            
            $segment = $this->uri->segment(4,0);  
            $temp_post = $this->input->post(NULL, TRUE);
            if(!$temp_post){
                $id_registrasi = trim($this->session->flashdata('id_registrasi'));
                $yayasan = trim($this->session->flashdata('yayasan'));
                $pti = trim($this->session->flashdata('pti'));
                $tgl_registrasi = trim($this->session->flashdata('tgl_registrasi'));
                $periode = trim($this->session->flashdata('periode'));
                $status_registrasi = trim($this->session->flashdata('status_registrasi'));
                $publish_verifikasi = trim($this->session->flashdata('publish_verifikasi'));
                $schema = trim($this->session->flashdata('schema'));
            }
            $temp_filter = array(
                        'id_registrasi' => $id_registrasi,                        
                        'yayasan' => $yayasan,
                        'pti' => $pti,                    
                        'tgl_registrasi' => $tgl_registrasi,
                        'periode' => $periode,
                        'schema' => $schema,
                        'status_registrasi' => $status_registrasi,
                        'publish_verifikasi' => $publish_verifikasi
                    );
            $this->session->set_flashdata($temp_filter);
            
            if($this->input->post('export')){
                $params = array(            
                    'paging' => array('row'=>'0','segment'=>'0')
                );
            }else{  
                $params = array(            
                    'paging' => array('row'=>10,'segment'=>$segment)
                );
            }
            
            if($id_registrasi != ''){                    
                $params['field']['registrasi.id_registrasi'] = $id_registrasi;
            }
            if($tgl_registrasi != ''){                
                $params['field']['registrasi.tgl_registrasi'] = $tgl_registrasi;
            }
            if($schema != ''){                
                $params['field']['registrasi.skema'] = $schema;
            }
            if($periode != ''){                
                $params['field']['registrasi.periode'] = $periode;
            }
            if($status_registrasi != ''){                    
                $params['field']['registrasi.id_status_registrasi'] = $status_registrasi;
            }
            if($yayasan != ''){
                $params['join']['tbl_badan_penyelenggara'] = 'registrasi.kdpti = tbl_badan_penyelenggara.kdpti';
                $params['field']['tbl_badan_penyelenggara.nama_penyelenggara'] = $yayasan;
            }
            if($pti != ''){
                $params['join']['tbl_pti'] = 'registrasi.kdpti = tbl_pti.kdpti';
                $params['field']['tbl_pti.nmpti'] = $pti;
            }
            if($publish_verifikasi != ''){
                $params['join']['verifikasi'] = 'registrasi.id_registrasi = verifikasi.id_registrasi';
                $params['field']['verifikasi.publish'] = $publish_verifikasi;
            }
                        
            $registrasi = new Registrasi();
            $result_registrasi = $registrasi->search($params);
            
            //config pagination                     
            $per_page = 10;
            $params['count'] = array('1');
            $total_row = $registrasi->search($params);
            $base_url = base_url() . 'backoffice/kelolaregistrasi/find/';
            setPagingTemplate($base_url, 4, $total_row, $per_page);
                       
            //data periode
            $mperiode = new Periode();
            $result_periode = $mperiode->get('0','0');
            $option_periode = array('' => '~Pilih~');      
            foreach ($result_periode->result() as $value) {
                $option_periode[$value->periode] = $value->periode;
            }            
            $data['periode'] = $option_periode;
            
            //data status registrasi
            $mstatus_registrasi = new StatusRegistrasi();
            $result_status = $mstatus_registrasi->get('0', '0');
            $option_status = array('' => '~Pilih~');      
            foreach ($result_status->result() as $value) {
                $option_status[$value->id_status_registrasi] = $value->nama_status;
            }            
            $data['status_registrasi'] = $option_status;
            
            $skema = array(''=>'-Pilih-','A'=>'A', 'B'=>'B', 'C'=>'C');
            //publish verifikasi
            $opt_verifikasi = array('' => '~Pilih~', 'yes' => 'Yes', 'no' => 'No');
            $data['publish_verifikasi'] = $opt_verifikasi;
            $data['skema'] = $skema;
            $data['registrasi'] = $result_registrasi;
            $data['total_row'] = $total_row;
            
            if ($this->input->post('export')) {
                $this->load->view('export_registrasi', $data, 'index_new');                
            } else {
                showBackEnd($view, $data, 'index_new');
            }
        } else {
            echo '<script>';
            echo 'alert("Validation Fail !");';
            echo 'window.history.back(1);';
            echo '</script>';
        }
    }

    public function index() {
        if ($this->sessionutility->validateAccess($this)) {
            $view = 'list_registrasi';
            $token = md5('service@silem');
            $registrasi = new Registrasi();
            $segment = $this->uri->segment(4, 0);
            $per_page = 10;
            $params = array(
                    'paging' => array('row'=>10,'segment'=>$segment)
                );
            $periode = new Periode();
            $periode->getBy('status_periode', 'open');                
            $current_periode = $periode->getOpenPeriode();
            //print_r($current_periode);
            $params['field']['registrasi.periode'] = $current_periode[0];            
            $result = $registrasi->search($params);
                        
            //data periode
            $result_periode = $periode->get('0','0');
            $option_periode = array('' => '~Pilih~');      
            foreach ($result_periode->result() as $value) {
                $option_periode[$value->periode] = $value->periode;
            }            
            $data['periode'] = $option_periode;
            
            //data status registrasi
            $status_registrasi = new StatusRegistrasi();
            $result_status = $status_registrasi->get('0', '0');
            $option_status = array('' => '~Pilih~');      
            foreach ($result_status->result() as $value) {
                $option_status[$value->id_status_registrasi] = $value->nama_status;
            }            
            $data['status_registrasi'] = $option_status;
            
            //publish verifikasi
            $opt_verifikasi = array('' => '~Pilih~', 'yes' => 'Yes', 'no' => 'No');
            $data['publish_verifikasi'] = $opt_verifikasi;
            
            $skema = array(''=>'-Pilih-','A'=>'A', 'B'=>'B', 'C'=>'C');
            //config pagination
            $params['count'] = array('1');
            $total_row = $registrasi->search($params);
            $base_url = base_url() . 'backoffice/kelolaregistrasi/index';
            setPagingTemplate($base_url, 4, $total_row, $per_page);
            $data['skema'] = $skema;
            $data['registrasi'] = $result;
            $data['total_row'] = $total_row;
            $data['token'] = $token;
            showBackEnd($view, $data, 'index_new');
        } else {
            echo '<script>';
            echo 'alert("Validation Fail !");';
            echo 'window.history.back(1);';
            echo '</script>';
        }
    }

    public function remove() {
        if ($this->sessionutility->validateAccess($this)) {
            
        } else {
            echo '<script>';
            echo 'alert("Validation Fail !");';
            echo 'window.history.back(1);';
            echo '</script>';
        }
    }

    public function detail($id_reg) {
        if ($this->sessionutility->validateAccess($this)) {
            $view = 'detail_registrasi';
            $registrasi = new Registrasi($id_reg);
            $token = md5('service@silem');
            $data['token'] = $token;
            $data['registrasi'] = $registrasi;
            add_footer_js('js/tinymce/tinymce.min.js');
            showBackEnd($view, $data, 'index_new');
        } else {
            echo '<script>';
            echo 'alert("Validation Fail !");';
            echo 'window.history.back(1);';
            echo '</script>';
        }
    }

    public function save() {
        $this->load->model('ModUserActivity');
        $userid = strtoupper($this->session->userdata('userid'));
        $acc = 0;
        $user = new ModUsers($userid);
        $access = new ModSubSystemModule('');
        $access->setUserId($user->getUserId());
        $subsysmodule = $access->getObjectList('', '');
        $uri = explode('/', $this->uri->uri_string());
        $class = get_class($this);
        if (($subsysmodule->num_rows()) > 0) {
            echo 'count:' . ($subsysmodule->num_rows()) . '</br>';
            foreach ($subsysmodule as $value) {
                $systemodule = new ModSystemModule($value->getModuleId());
                if ($systemodule->getModuleName() == $class) {
                    if (count($uri) <= 2) {
                        if ($value->getSubModuleName() == 'index') {
                            $acc = 1;
                            break;
                        }
                    } elseif (strtolower($value->getSubModuleName()) == strtolower($uri[2])) {
                        $acc = 1;
                        echo 'access type: ' . $value->getAccessTypeId() . '</br>';
                        if ($value->getAccessTypeId() == '1' ||
                                $value->getAccessTypeId() == '3' ||
                                $value->getAccessTypeId() == '4') {
                            echo 'access type: ' . $value->getAccessTypeId() . '</br>';
                            $userActivity = new ModUserActivity('');
                            $userActivity->m_ModUsers = new ModUsers($userid);
                            $qrystring = $this->uri->uri_string();
                            $userActivity->setModuleAccessed($qrystring);
                            $userActivity->settimeAccessed(date('c'));
                            $userActivity->insert();
                        }
                        break;
                    }
                }
            }
        }
        echo 'access is: ' . $acc;
    }

    public function verifikasi() {
        if ($this->sessionutility->validateAccess($this)) {
            $id_registrasi = trim($this->input->post('id'));
            $status = trim($this->input->post('status'));
            $keterangan = trim($this->input->post('keterangan'));

            $registrasi = new Registrasi($id_registrasi);
            $status_reg = $registrasi->getStatusRegistrasi();
            $verifikasi = new Verifikasi($id_registrasi);

            //$data = '';
            $response = '';
            if ($verifikasi->getIdRegistrasi() == '') {//insert
                $verifikasi->setIdRegistrasi($id_registrasi);
                $verifikasi->setIdStatusRegistrasi($status);
                $verifikasi->setKeterangan($keterangan);
                $verifikasi->setTglVerifikasi(date('Y-m-d'));
                $verifikasi->setPublish('no');
                if ($verifikasi->insert()) {
                    $registrasi->setIdStatusRegistrasi($status);
                    //$registrasi->update();
                    $response = 'true';
                } else {
                    $response = 'false';
                }
            } else {
                $verifikasi->setIdRegistrasi($id_registrasi);
                $verifikasi->setIdStatusRegistrasi($status);
                $verifikasi->setKeterangan($keterangan);
                $verifikasi->setTglVerifikasi(date('Y-m-d'));
                $verifikasi->setPublish('no');
                if ($verifikasi->update()) {
                    $registrasi->setIdStatusRegistrasi($status);
                    //$registrasi->update();
                    $response = 'true';
                } else {
                    $response = 'false';
                }
            }

            $status_registrasi = new StatusRegistrasi($status);
            $data[0] = array('message' => $response, 'status' => $status_registrasi->getNamaStatus());

            echo json_encode($data);
        } else {
            echo '<script>';
            echo 'alert("Validation Fail !");';
            echo 'window.history.back(1);';
            echo '</script>';
        }
    }

    public function publishVerifikasi($id_registrasi, $status) {
        if ($this->sessionutility->validateAccess($this)) {
            $registrasi = new Registrasi($id_registrasi);
            $verifikasi = $registrasi->getVerifikasi();
            $status_verifikasi = $verifikasi->getIdStatusRegistrasi();
            if ($status == 'true') {
                $registrasi->setIdStatusRegistrasi($status_verifikasi);
                $registrasi->setPenugasan('0');
                $verifikasi->setPublish('yes');
                $verifikasi->update();
                $result = $registrasi->update();
            } else {
                $registrasi->setIdStatusRegistrasi('1');
                $registrasi->setPenugasan('0');
                $verifikasi->setPublish('no');
                $verifikasi->update();
                $result = $registrasi->update();
            }
            if ($result) {
                echo "Verifikasi Ok";
            } else {
                echo "Verifikasi Gagal";
            }
        } else {
            echo '<script>';
            echo 'alert("Validation Fail !");';
            echo 'window.history.back(1);';
            echo '</script>';
        }
    }

    public function updateDocument($idupload, $status) {
        if ($this->sessionutility->validateAccess($this)) {
            $dokumen_reg = new DokumenRegistrasi($idupload);
            $label = '';
            if ($status == 'true') {
                $dokumen_reg->setVerifikasi('y');
                $label = 'Verified';
            } else {
                $dokumen_reg->setVerifikasi('n');
                $label = 'Unverified';
            }
            $dokumen_reg->update();
            echo $label;
        } else {
            echo '<script>';
            echo 'alert("Validation Fail !");';
            echo 'window.history.back(1);';
            echo '</script>';
        }
    }

    public function exportVerifikasi($id_registrasi) {
        $registrasi = new Registrasi($id_registrasi);
        $verifikasi = new Verifikasi($id_registrasi);
        $pti = new Pti($registrasi->getKdPti());
        $dokumen = new Dokumen();
        $result_dokumen = $dokumen->get('0', '0');
        $dokumen_registrasi = new DokumenRegistrasi();

        // Create new PHPExcel object
        $objPHPExcel = new PHPExcel();

        // Set document properties
        $objPHPExcel->getProperties()->setCreator("pppts.ristekdikti.go.id")
                ->setLastModifiedBy("Admin")
                ->setTitle("Verifikasi")
                ->setSubject("Laporan Hasil Verifikasi");
        // Add some data
        $objPHPExcel->setActiveSheetIndex(0);
        //header
        $objPHPExcel->getActiveSheet()->setCellValue('A1', 'FM.DESK-01');
        $objPHPExcel->getActiveSheet()->setCellValue('A2', 'DOKUMEN ADMINISTRASI');
        $objPHPExcel->getActiveSheet()->setCellValue('A3', 'DESK EVALUATION PROGRAM PEMBINAAN PTS');
        //data pts
        $objPHPExcel->getActiveSheet()->setCellValue('A5', 'Nama PT: ' . $pti->getNmPti());
        $objPHPExcel->getActiveSheet()->setCellValue('A6', 'Kopertis: ');
        $objPHPExcel->getActiveSheet()->setCellValue('A7', 'Nama Reviewer: ');
        $objPHPExcel->getActiveSheet()->setCellValue('A8', 'Institusi Asal Reviewer:');
        $objPHPExcel->getActiveSheet()->setCellValue('A9', 'Tanggal Evaluasi:' . $verifikasi->getTglVerifikasi());
        //tabel nilai            
        $objPHPExcel->getActiveSheet()->setCellValue('A11', 'No');
        $objPHPExcel->getActiveSheet()->setCellValue('B11', 'Dokumen');
        $objPHPExcel->getActiveSheet()->setCellValue('C11', 'Panduan Skor');
        $objPHPExcel->getActiveSheet()->setCellValue('E11', 'Skor');
        $objPHPExcel->getActiveSheet()->setCellValue('F11', 'Nilai');
        $objPHPExcel->getActiveSheet()->setCellValue('G11', 'Informasi Dari Lampiran');
        $objPHPExcel->getActiveSheet()->setCellValue('C12', '1');
        $objPHPExcel->getActiveSheet()->setCellValue('D12', '0');

        $row = 13;
        $no = 1;
        foreach ($result_dokumen->result() as $obj) {
            $dokumen_registrasi->getByArray(array('id_registrasi' => $registrasi->getIdRegistrasi(), 'id_form' => $obj->id_form));
            $dokumen = $dokumen_registrasi->getDokumen();
            $hasil_verify = $dokumen_registrasi->verifikasi;
            $skor = '';
            if ($hasil_verify == 'y') {
                $skor = '1';
            } else {
                $skor = '0';
            }
            $objPHPExcel->getActiveSheet()->setCellValue('A' . strval($row), $no);
            $objPHPExcel->getActiveSheet()->setCellValue('B' . strval($row), $dokumen->getFormName());

            $objPHPExcel->getActiveSheet()->setCellValue('C' . strval($row), 'Ada 100%');
            $objPHPExcel->getActiveSheet()->setCellValue('D' . strval($row), 'Tidak Ada atau < 100%');

            $objPHPExcel->getActiveSheet()->setCellValue('E' . strval($row), $skor);
            $row++;
            $no++;
        }

        //formating the look
        //merge cells
        //title
        $objPHPExcel->getActiveSheet()->mergeCells('A1:H1');
        $objPHPExcel->getActiveSheet()->mergeCells('A2:H2');
        $objPHPExcel->getActiveSheet()->mergeCells('A3:H3');

        $objPHPExcel->getActiveSheet()->mergeCells('A5:B5');
        $objPHPExcel->getActiveSheet()->mergeCells('A6:B6');
        $objPHPExcel->getActiveSheet()->mergeCells('A7:B7');
        $objPHPExcel->getActiveSheet()->mergeCells('A8:B8');
        $objPHPExcel->getActiveSheet()->mergeCells('A9:B9');
        //table head
        $objPHPExcel->getActiveSheet()->mergeCells('C11:D11');
        $objPHPExcel->getActiveSheet()->mergeCells('A11:A12');
        $objPHPExcel->getActiveSheet()->mergeCells('B11:B12');
        $objPHPExcel->getActiveSheet()->mergeCells('E11:E12');
        $objPHPExcel->getActiveSheet()->mergeCells('F11:F12');
        $objPHPExcel->getActiveSheet()->mergeCells('G11:G12');

        //fonts
        $objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setSize(14);
        $objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
        $objPHPExcel->getActiveSheet()->getStyle('A2')->getFont()->setSize(14);
        $objPHPExcel->getActiveSheet()->getStyle('A2')->getFont()->setBold(true);
        $objPHPExcel->getActiveSheet()->getStyle('A3')->getFont()->setSize(14);
        $objPHPExcel->getActiveSheet()->getStyle('A3')->getFont()->setBold(true);

        $objPHPExcel->getActiveSheet()->getStyle('A5')->getFont()->setBold(true);
        $objPHPExcel->getActiveSheet()->getStyle('A6')->getFont()->setBold(true);
        $objPHPExcel->getActiveSheet()->getStyle('A7')->getFont()->setBold(true);
        $objPHPExcel->getActiveSheet()->getStyle('A8')->getFont()->setBold(true);
        $objPHPExcel->getActiveSheet()->getStyle('A9')->getFont()->setBold(true);

        //auto column width and alignment
        $objPHPExcel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
        $objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(20);
        $objPHPExcel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->getActiveSheet()->getStyle('A2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
        $objPHPExcel->getActiveSheet()->getStyle('A3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        //border
        $styleThinBlackBorderOutline = array(
            'borders' => array(
                'outline' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN,
                    'color' => array('argb' => 'FF000000'),
                ),
                'inside' => array(
                    'style' => PHPExcel_Style_Border::BORDER_THIN,
                    'color' => array('argb' => 'FF000000'),
                ),
            ),
        );
        $objPHPExcel->getActiveSheet()->getStyle('A11:G' . $row)->applyFromArray($styleThinBlackBorderOutline);
        
        //shading
        $objPHPExcel->getActiveSheet()->getStyle('A11:G12')->applyFromArray(
                array(
                    'font' => array(
                        'bold' => true
                    ),
                    'alignment' => array(
                        'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
                        'vertical' => PHPExcel_Style_Alignment::VERTICAL_CENTER
                    ), 'fill' => array(
                        'type' => PHPExcel_Style_Fill::FILL_SOLID,
                        'color' => array('argb' => 'd5d8c5')
                    )
                )
        );

        // Redirect output to a client’s web browser (Excel2007)
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="' . $pti->getNmPti() . '.xlsx"');
        header('Cache-Control: max-age=0');
        // If you're serving to IE 9, then the following may be needed
        header('Cache-Control: max-age=1');

        // If you're serving to IE over SSL, then the following may be needed
        header('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT'); // always modified
        header('Cache-Control: cache, must-revalidate'); // HTTP/1.1
        header('Pragma: public'); // HTTP/1.0

        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
        $objWriter->save('php://output');
    }
    
    public function testApiPddikti()
    {
        
    }

}

?>