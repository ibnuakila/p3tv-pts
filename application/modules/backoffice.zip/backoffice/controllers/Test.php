<?php

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
/**
 * @author akil
 * @version 1.0
 * @created 14-Mar-2016 11:12:35
 */
class Test extends MX_Controller
{

	function __construct()
	{
		parent::__construct();
		$this->load->model('Modusers');
		$this->load->library('sessionutility');

		 
	}

	function __destruct()
	{
	}
	
	public function index()
	{
		$this->load->model('evaluasi');
		$evaluasi = new Evaluasi();
		echo $evaluasi->generateId('1');
	}
	
	public function testRead()
	{
		/*$path = 'C:/xampp/htdocs/pppts/assets/documents/template_penilaian.xlsx';
			$result = $this->readInstrument($path);
			print_r($result);*/
		$evaluasi = new Evaluasi();
		$result_evaluasi = $evaluasi->getByRelated('registrasi', 'id_registrasi', '1', '0','0');
		//print_r($result_evaluasi);
		foreach ($result_evaluasi->result()  as $row){
			echo $row->skor.'</br>';
		}
	}
	
	public function testItem()
	{
		$this->load->model('itemhibah');
		$itemh = new ItemHibah();
		$arr = array('id_item' => '01080103b', 
				'id_registrasi' => '170610110403');
		if($itemh->getByArray($arr)){
			echo 'ongkir = '. $itemh->getOngkir();
		}
	}
        
        public function indexregistrasi()
        {
            $this->load->view('test');
        }
        
        public function getStatePenyelenggara()
        {
            $token = md5('service@silem');
            $username = 'evapro'; $password = 'service@silem';
            //The JSON data.
            //$this->inquerySecurityKey() ;
            echo 'key: '.$token.'</br>';
            $penyelenggara_id = 'Y15025';
            $url = 'http://silemkerma.ristekdikti.go.id/evapro/evaservice/getstatuspenyelenggara/'.$token.'/'.$penyelenggara_id;
            //Initiate cURL.
            $ch = curl_init($url);
            
            //Encode the array into JSON.
            //$jsonDataEncoded = json_encode($data);
            //echo $jsonDataEncoded;
            //Tell cURL that we want to send a POST request.
            curl_setopt($ch, CURLOPT_POST, 1);

            //Attach our encoded JSON string to the POST fields.
            curl_setopt($ch, CURLOPT_POSTFIELDS, array('token' => $token, 'penyelenggara_id' => $penyelenggara_id));

            //Set the content type to application/json
            curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json')); 
            //set the return of the transfer as string
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            // Optional, delete this line if your API is open
            curl_setopt($ch, CURLOPT_USERPWD, $username . ':' . $password);
            //Execute the request
            $result = curl_exec($ch);
            echo $result;
            //return json_decode($result);
        }
        
        public function getBase64Encode()
        {
            $consumer_key = 'MxtDfHAoDGwTMg96kGpSLg9C4fIa';
            $consumer_secret = 'eaSOaz9hleXT2ATxDlu_fXgEhssa';
            $encoded = base64_encode($consumer_key.':'.$consumer_secret);
            echo $encoded;
        }
        
        public function testApiPdDikti()
        {
            $consumer_key = 'u9PZ1eED9cjkY_OHvpnAkDDK9_8a';//'MxtDfHAoDGwTMg96kGpSLg9C4fIa';
            $consumer_secret = 'YQ5aCZFnDHYHGFgtAitqS2LSXqQa';//'eaSOaz9hleXT2ATxDlu_fXgEhssa';
            
            $encoded_access = base64_encode($consumer_key.':'.$consumer_secret);
            //The JSON data.
            echo 'key: '.$consumer_key.':'.$consumer_secret.'</br>';
            echo 'encoded key: '.$encoded_access.'</br>';
            
            
            $url = 'https://api.kemdikbud.go.id:8243/token';
            echo 'url: '.$url.'</br>';
            //Initiate cURL.
            $ch = curl_init($url);
            $params['grant_type'] = 'password';
            $params['username'] = $consumer_key;
            $params['password'] = $consumer_secret;
            //Encode the array into JSON.
            //$jsonDataEncoded = json_encode($params);
            //echo $jsonDataEncoded;
            //Tell cURL that we want to send a POST request.
            curl_setopt($ch, CURLOPT_POST, 1);

            //Attach our encoded JSON string to the POST fields.
            
            curl_setopt($ch, CURLOPT_POSTFIELDS, $params);

            //Set the content type to application/json
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/x-www-form-urlencoded',
                'Authorization: Basic '.$encoded_access)); 
            //set the return of the transfer as string
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            // Optional, delete this line if your API is open
            //curl_setopt($ch, CURLOPT_USERPWD, $consumer_key . ':' . $consumer_secret);
            //Execute the request
            $result = curl_exec($ch);
            echo $result;
            //return json_decode($result);
        }
	
        public function testid(){
            $thn = date('y');
            $bln = date('m');
            $tgl = date('d');
            $time = date('s');
            $tempno = $tgl . $bln . $thn;
            $autono = mt_rand(1, 99);
            echo 'id: '.$tempno.$time.$autono;
        }
        
        public function testdownload()
        {
            $this->load->model('dokumenregistrasi');
            $this->load->helper('download');
            
            $dokumen_registrasi = new DokumenRegistrasi();
            $res_dok_reg = $dokumen_registrasi->getByRelated('registrasi', 'id_registrasi', '191120143718', '0', '0');
            if($res_dok_reg->num_rows()>0){
                $row = $res_dok_reg->row();
                $filepath = $row->filepath;
                $base_path = '/home/pppts/frontends/frontend/web/'.$filepath;
                if(is_file($base_path)){
                $data = file_get_contents($base_path);
                force_download('dokumen.pdf', $data);
                }else{
                    echo 'File not found!';
                }
            }
        }
        
        public function readExcel()
        {
            
            $inputFileName = realpath(APPPATH . '../assets/documents/example1.xlsx');

            $inputFileType = IOFactory::identify($inputFileName);
            //$helper->log('File ' . pathinfo($inputFileName, PATHINFO_BASENAME) . ' has been identified as an ' . $inputFileType . ' file');

            //$helper->log('Loading file ' . pathinfo($inputFileName, PATHINFO_BASENAME) . ' using IOFactory with the identified reader type');
            $reader = IOFactory::createReader($inputFileType);
            $spreadsheet = $reader->load($inputFileName);
            
            //$sheetData = $spreadsheet->getActiveSheet()->toArray(null, true, true, true);
            //var_dump($sheetData);
            for($i=2; $i<=8; $i++){
                echo $spreadsheet->getActiveSheet()->getCell('A'.$i)->getCalculatedValue().' | '.
                $spreadsheet->getActiveSheet()->getCell('B'.$i)->getCalculatedValue().'</br>';
            }
            
        }
	
}