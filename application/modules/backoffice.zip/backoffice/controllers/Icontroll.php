<?php




/**
 * @author akil
 * @version 1.0
 * @created 26-Mar-2016 19:15:23
 */
interface IControll
{

	public function add();

	public function edit();

	public function find();

	public function index();

	public function remove();

	public function save();

}
?>