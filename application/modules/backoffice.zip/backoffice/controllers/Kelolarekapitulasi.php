<?php
require_once ('Icontroll.php');

require_once APPPATH . 'third_party/PHPExcel.php';
require_once APPPATH . 'third_party/PHPExcel/IOFactory.php';


//use ;
/**
 * @author akil
 * @version 1.0
 * @created 26-Mar-2016 19:15:18
 */
class KelolaRekapitulasi extends MX_Controller implements IControll
{

	function __construct()
	{
		parent::__construct();
        $this->load->library('sessionutility');
        $this->load->library('form_validation');
        if (!$this->sessionutility->validateSession()) {
            redirect(base_url() . 'backoffice/');
        }
        $this->load->model('paket');
        $this->load->model('detailpakethibah');
        $this->load->model('detailpaketkirim');
        $this->load->model('supplier');
        $this->load->model('itemhibah');
        $this->load->model('registrasi');
        $this->load->model('barang');
	}

	function __destruct()
	{
	}



	public function add()
	{
	}

	public function edit()
	{
	}

	public function find()
	{
		//if ($this->sessionutility->validateAccess($this)) {
			if($this->input->post('export')){
				$detail_hibah = new DetailPaketHibah();
				$result = $detail_hibah->getRekap('0','0');
				// Create new PHPExcel object
				$objPHPExcel = new PHPExcel();

				// Set document properties
				$objPHPExcel->getProperties()->setCreator("pppts.ristekdikti.go.id")
											->setLastModifiedBy("Admin")
											->setTitle("Form Monitoring PPPTS 2017")
											->setSubject("Laporan Monitoring PPPTS 2017");
				// Add some data
				$objPHPExcel->setActiveSheetIndex(0);
				$objPHPExcel->getActiveSheet()->setCellValue('A1', 'No');
				$objPHPExcel->getActiveSheet()->setCellValue('B1', 'Kota');
				$objPHPExcel->getActiveSheet()->setCellValue('C1', 'Nama PT');
				$objPHPExcel->getActiveSheet()->setCellValue('D1', 'Sub Total');
				$objPHPExcel->getActiveSheet()->setCellValue('E1', 'PPN 10%');
				$objPHPExcel->getActiveSheet()->setCellValue('F1', 'Total Anggaran');
				$r=2; $no = 0;
				foreach($result->result() as $row){
					$pt = new PTI($row->kdpti);
					$ppn = $row->total * 0.1;
					$total_anggaran = $row->total + $ppn;
					
					$objPHPExcel->getActiveSheet()->setCellValue('A'.$r, ++$no);
					$objPHPExcel->getActiveSheet()->setCellValue('B'.$r, ucfirst($row->wilayah));
					$objPHPExcel->getActiveSheet()->setCellValue('C'.$r, $pt->getNmPti());
					$objPHPExcel->getActiveSheet()->setCellValue('D'.$r, $row->total);					
					$objPHPExcel->getActiveSheet()->setCellValue('E'.$r, $ppn);					
					$objPHPExcel->getActiveSheet()->setCellValue('F'.$r, $total_anggaran);
					
					$objPHPExcel->getActiveSheet()->getStyle('D'.$r)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
					$objPHPExcel->getActiveSheet()->getStyle('E'.$r)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
					$objPHPExcel->getActiveSheet()->getStyle('F'.$r)->getNumberFormat()->setFormatCode(PHPExcel_Style_NumberFormat::FORMAT_NUMBER_COMMA_SEPARATED1);
					$r++; 
				}
				$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
				$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
				$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
				$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
				$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setAutoSize(true);
				
				//download
				// Redirect output to a client’s web browser (Excel2007)
				header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
				header('Content-Disposition: attachment;filename="data.xlsx"');
				header('Cache-Control: max-age=0');
				// If you're serving to IE 9, then the following may be needed
				header('Cache-Control: max-age=1');

				// If you're serving to IE over SSL, then the following may be needed
				header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
				header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
				header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
				header ('Pragma: public'); // HTTP/1.0

				$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
				$objWriter->save('php://output');
			}else{
				
			}
		/*} else {
            echo '<script>';
            echo 'alert("Validation Fail !");';
            echo 'window.history.back(1);';
            echo '</script>';
        }*/
	}

	public function index()
	{
		if ($this->sessionutility->validateAccess($this)) {
            $view = 'list_pagu';
			$detail_hibah = new DetailPaketHibah();
			$result = $detail_hibah->getRekap('0','0');
			
            $data['rekap'] = $result;
            showBackEnd($view, $data);
        } else {
            echo '<script>';
            echo 'alert("Validation Fail !");';
            echo 'window.history.back(1);';
            echo '</script>';
        }
	}

	public function remove()
	{
	}

    public function save() {
        
    }

}
?>