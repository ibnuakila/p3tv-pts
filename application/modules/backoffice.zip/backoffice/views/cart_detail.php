<div class="mt-auto mb-1">
    <?php
    $registrasi = new Registrasi($id_registrasi);
    $pt = $registrasi->getPti();
    ?>
    <h3 class="display-5">
        Usulan Barang <?= $pt->getNmPti() ?>
    </h3><hr>
    <div class="table-responsive">
        <table class="table table-striped table-condensed">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Barang</th>
                    <th>Spesifikasi</th>
                    <th>Qty</th>
                    <th>Sub Total</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if($item_hibah->num_rows()>0){
                    $i=1; $grand_total=0; $nama = ''; $spesifikasi = ''; $ppn = 0;
                    foreach ($item_hibah->result() as $row){
                        if($registrasi->getJnsUsulan()=='01'){                            
                            $item_barang = new ItemBarang($row->id_item);
                            $nama = $item_barang->getBarang();
                            $spesifikasi = $item_barang->getSpesifikasi();
                            $ppn = ($row->subtotal*10)/100;
                        }elseif ($registrasi->getJnsUsulan()=='02') {                            
                            $item_barang = new ItemGedung($row->id_item);
                            $nama = $item_barang->getNmGedung();
                            $spesifikasi = $item_barang->getNmGedung();
                            $ppn = 0;
                        }else{
                            if(strlen($row->id_item)==9 ){
                                $item_barang = new ItemBarang($row->id_item);
                                $nama = $item_barang->getBarang();
                                $spesifikasi = $item_barang->getSpesifikasi();
                                $ppn = ($row->subtotal*10)/100;
                            }else{
                                $item_barang = new ItemGedung($row->id_item);
                                $nama = $item_barang->getNmGedung();
                                $spesifikasi = $item_barang->getNmGedung();
                                $ppn = 0;
                            }
                        }
                        
                        $subtotal_ppn = $row->subtotal + $ppn;
                        $grand_total = $grand_total + $subtotal_ppn;
                ?>
                <tr>
                    <td><?=$i ?></td>
                    <td><?=$nama ?></td>
                    <td><?=$spesifikasi ?></td>
                    <td><?=$row->jml_item ?></td>
                    <td><?= number_format($subtotal_ppn,2) ?></td>
                    <td>
                        <a href="#" title="Edit" class="edit" data-toggle="modal" 
                            data-target="#modal-detail" id="<?= $row->id ?>"><i class="fa fa-edit"></i></a>
                        <a href="#" title="Remove" class="remove" id="<?=$row->id ?>"><i class="fa fa-remove"></i></a>
                    </td>
                </tr>
                <?php $i++;
                    }?>
                <tr>
                    <td colspan="4"><b>Grand Total (Sudah Termasuk Pajak):</b></td>
                    <td colspan="2"><b><?='Rp. '.number_format($grand_total,2) ?></b></td>
                    
                </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
        <?php
        $rekapitulasi = new Rekapitulasi();
        $rekapitulasi->getBy('id_registrasi', $id_registrasi);
            if($rekapitulasi->getIdStatusRegistrasi()!='7'){
        ?>
        <a href="<?= base_url().'backoffice/kelolabarang/finish/'.$id_registrasi ?>" class="btn btn-outline-primary">Selesai</a>
            <?php } ?>
        <a href="<?= base_url().'backoffice/kelolabarang/printdatabarang/'.$id_registrasi ?>" class="btn btn-outline-success">Cetak</a>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="modal-detail" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Detail Barang</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="col-md-12">
                    <img src="<?= base_url() ?>assets/images/no-image-2.png" class="card-img" alt="..." id="img-barang">
                </div>
                <div class="col-md-12">
                    <div class="card-body">
                        <h4 class="card-title" id="title-barang">Card title</h4><hr>
                        <h5 id="lbl-harga" class="text-right">Rp.</h5>
                        
                                <div class="form-group text-right">
                                    <label class="text-right"><b>Qty:</b></label>
                                    <input type="text" class="form-control-sm" name="txt-qty" id="txt-qty" style="width:50px;" value="0">
                                    <input type="hidden" id="id" value="">
                                    <input type="hidden" id="id-item" value="">
                                    <input type="hidden" id="id-registrasi" value="">
                                </div>
                                <h5 id="lbl-sub-total" class="text-right">Rp.</h5>
                        <h5>Spesifikasi:</h5>
                        <p class="card-text text-monospace text-muted text-justify" id="text-spesifikasi">This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>

                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <input type="hidden" id="flag" value="false">
                <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Close</button>
                <button type="button" class="btn btn-outline-primary" id="btn-save">Save changes</button>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript" >
    $("document").ready(function () {
        
        
        $(document.body).on("click", ".remove", function (event) {
            
            var id = $(this).attr("id");
            var question = confirm("Yakin dihapus");
            if(question){
                
                $.ajax({
                    url: '<?php echo base_url() . 'backoffice/kelolabarang/remove/'; ?>',
                    dataType: 'json',
                    type: 'POST',
                    data: {id: id},
                    success: function (response) {
                        alert(response[0].message);
                        document.location.reload();
                    }
                });
            }
            event.preventDefault();
        });
        
        
        
        $(document.body).on("click", ".edit", function ()
        {
            var idItem = $(this).attr('id');
            //alert("id item" + idItem);
            $.ajax({
                url: '<?php echo base_url() . 'backoffice/kelolabarang/getbaranghibah/'; ?>',
                dataType: 'json',
                type: 'POST',
                data: {id: idItem},
                success: function (response) {
                    $("#title-barang").text(response[0].barang + " (" + response[0].no_barang + ")");
                    $("#img-barang").attr("src", response[0].image);
                    $("#lbl-harga").text("Rp. " + response[0].harga_satuan);
                    $("#lbl-sub-total").text("Sub Total: Rp. " + response[0].sub_total);
                    $("#txt-qty").val(response[0].qty);
                    $("#text-spesifikasi").text(response[0].spesifikasi);
                    $("#id-item").val(response[0].id_item);
                    $("#id").val(response[0].id);
                    $("#id-registrasi").val(response[0].id_registrasi);
                }
            });
        });
        
        $(document.body).on("click", "#btn-save", function () {
            //alert("you clicked me!");
            var idItem = $("#id-item").val();
            var idRegistrasi = $("#id-registrasi").val();
            var qty = $("#txt-qty").val();
            var flag = $("#flag").val();
            var id = $("#id").val();
            $.ajax({
                url: '<?php echo base_url() . 'backoffice/kelolabarang/save/'; ?>',
                dataType: 'json',
                type: 'POST',
                data: {id: id, id_item: idItem, id_registrasi: idRegistrasi, qty: qty, flag: flag},
                success: function (response) {
                    alert(response[0].message);
                    $("#lbl-total").text("Rp. " + response[0].grand_total);
                    $("#lbl-sub-total").text("Sub Total: Rp. " + response[0].sub_total);
                    $("#cart").text(" Cart (" + response[0].count + ")");
                    //$("#btn-save").attr("disabled", "disabled");
                }
            });
            document.location.reload();
        });
    });
</script>
