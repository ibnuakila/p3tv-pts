<script type="text/javascript">
    /*tinymce.init({
        selector: "textarea",
        plugins: [
            "advlist autolink lists link image charmap print preview anchor",
            "searchreplace visualblocks code fullscreen",
            "insertdatetime media table contextmenu paste moxiemanager"
        ],
        toolbar: "undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent"
    });*/
</script>
<script type="text/javascript">
    /*$("document").ready(function () {
     var _penyelenggara_id = $("#penyelenggara_id").val();
     var _token = $("#token").val();
     $.ajax({
     type: "POST",
     dataType: "json",
     url: "http://silemkerma.ristekdikti.go.id/evapro/evaservice/getstatuspenyelenggara/",
     data: {token: _token, penyelenggara_id: _penyelenggara_id},
     success:
     function (data) {
     if (data.length > 0) {
     //alert("OK!");
     
     $("#status_perubahan").html((data[0].status_usulan));
     } else {
     //alert("Verifikasi Fail!");
     $("#status_perubahan").html("Tidak ada usulan");
     }
     }
     });
     event.preventDefault();
     });*/
</script>
<script type="text/javascript">
    $("document").ready(function () {

       $("#approved").click(function (event) {
            
            var _keterangan = $("#keterangan").val();
            var _id = $("#idregistrasi").val();
            var status = '2';
            alert("Id"+_id);
            event.preventDefault();
            $.ajax({
                type: "POST",
                dataType: "json",
                url: "<?= base_url() ?>backoffice/kelolaregistrasi/verifikasi",
                data: {id: _id, status: status, keterangan: _keterangan},
                success:
                        function (data) {
                            if (data[0].message == "true") {
                                alert("Verifikasi OK!");
                                $("#approved").attr('disabled', 'disabled');
                                $("#disapproved").removeAttr('disabled');
                                $("#status_ver").val(data[0].status);
                            } else {
                                alert("Verifikasi Fail!");
                            }
                        }
            });
            
        });

        $("#disapproved").click(function (event) {
            var _keterangan = $("textarea#keterangan").val(); //tinyMCE.activeEditor.getContent();
            var _id = $("#idregistrasi").val();
            var status = '6';
            alert("Id"+_id);
            event.preventDefault();
            $.ajax({
                type: "POST",
                dataType: "json",
                url: "<?= base_url() ?>backoffice/kelolaregistrasi/verifikasi",
                data: {id: _id, status: status, keterangan: _keterangan},
                success:
                        function (data) {
                            if (data[0].message == "true") {
                                alert("Verifikasi OK!");
                                $("#disapproved").attr('disabled', 'disabled');
                                $("#approved").removeAttr('disabled');
                                $("#status_ver").val(data[0].status);
                            } else {
                                alert("Verifikasi Fail!");
                            }
                        }
            });
            
        });

        $(document.body).on("click", ".view", function ()
        {
            var id = $(this).attr("id");
            var src = $(this).attr("src");
            //alert(src);
            $("#pdfview").attr("src", src);
        });

        $(document.body).on("click", ".tersedia", function ()
        {
            var id = $(this).attr("id");
            //alert(id);
            var status = $("#" + id).is(":checked");
            $.ajax
                    ({
                        type: "POST",
                        url: "<?php echo base_url() . 'backoffice/kelolaregistrasi/updatedocument/' ?>" + id + "/" + status,
                        success: function (msg)
                        {
                            //alert(msg); 
                            $("#lbl_" + id).text(msg);
                        }
                    });

        });
    });
</script>
<script language=javascript>
    function deleteDocument()
    {
        var answer = confirm("Yakin dihapus ?");
        if (answer) {
            document.messages.submit();
        }

        return false;

    }
</script>  

    <div class="card">
        <div class=" card-header"><i class="fa fa-list"></i> Detail Registrasi</div>
        <div class=" card-body">
            <div class="row-fluid">
                <form action="" class="form-horizontal">
                    <?php
                    //$account = $registrasi->getAccount();
                    //$yayasan = $account->getYayasan();
                    $pt = $registrasi->getPti();
                    $pdpt = $registrasi->getLaporanPdpt();
                    $nmyayasan = '-';
                    $ketua = '';
                    $alamat = '';
                    $akte = '';
                    $notaris = '';
                    $pengesahan = '';
                    $email = '';
                    $penyelenggara = $registrasi->getPenyelenggara();
                    $penyelenggara_id = '';
                    $ubah_pt = $registrasi->getUbahPt();
                    $rencana_ubah_pt = $registrasi->getRencanaUbahPt();
                    if (is_object($penyelenggara)) {
                        $nmyayasan = $penyelenggara->getNamaPenyelenggara();
                        $ketua = $penyelenggara->getKetuaPenyelenggara();
                        $alamat = $penyelenggara->getAlamat();
                        $akte = $penyelenggara->getNoAkteNotaris();
                        $notaris = $penyelenggara->getNamaNotaris();
                        $pengesahan = $penyelenggara->getNoSuratPengesahan();
                        $email = $penyelenggara->getEmail();
                        $penyelenggara_id = $penyelenggara->getPenyelenggaraId();
                    }
                    $status = $registrasi->getStatusRegistrasi();
                    $skema = $registrasi->getSchema();
                    if ($skema == '') {
                        $skema = 'A';
                    }
                    $verifikasi = new Verifikasi($registrasi->getIdRegistrasi());
                    $status_verifikasi = $verifikasi->getIdStatusRegistrasi();
                    $objStatus = new StatusRegistrasi($status_verifikasi);
                    ?>
                    <input type="hidden" id="idregistrasi" value="<?= $registrasi->getIdRegistrasi() ?>">
                    <!-- <input type="hidden" id="token" value="<?= $token ?>">-->
                    <div class="form-group">
                        <label for="yayasan" class="col-lg-3 control-label">Yayasan:</label>
                        <div class="col-lg-6">
                            <input type="text" class="form-control input-sm" disabled name="yayasan" value="<?= $nmyayasan ?>">                                        
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="yayasan" class="col-lg-3 control-label">Ketua:</label>
                        <div class="col-lg-6">
                            <input type="text" class="form-control input-sm" disabled name="ketua" value="<?= $ketua ?>">                                        
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="yayasan" class="col-lg-3 control-label">Alamat:</label>
                        <div class="col-lg-6">
                            <input type="text" class="form-control input-sm" disabled name="alamat" value="<?= $alamat ?>">                                        
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="yayasan" class="col-lg-3 control-label">No Akte Notaris:</label>
                        <div class="col-lg-6">
                            <input type="text" class="form-control input-sm" disabled name="akte" value="<?= $akte ?>">                                        
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="yayasan" class="col-lg-3 control-label">Nama Notaris:</label>
                        <div class="col-lg-6">
                            <input type="text" class="form-control input-sm" disabled name="notaris" value="<?= $notaris ?>">                                        
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="yayasan" class="col-lg-3 control-label">No Surat Pengesahan:</label>
                        <div class="col-lg-6">
                            <input type="text" class="form-control input-sm" disabled name="pengesahan" value="<?= $pengesahan ?>">                                        
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="yayasan" class="col-lg-3 control-label">Email:</label>
                        <div class="col-lg-6">
                            <input type="text" class="form-control input-sm" disabled name="email" value="<?= $email ?>">                                        
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="pt" class="col-lg-3 control-label">Perguruan Tinggi:</label>
                        <div class="col-lg-6">
                            <input type="text" class="form-control input-sm" disabled name="pt" value="<?= $pt->getNmPti(); ?>">                                        
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="pt" class="col-lg-3 control-label">Tgl Registrasi:</label>
                        <div class="col-lg-6">
                            <input type="text" class="form-control input-sm" disabled name="tgl_reg" value="<?= $registrasi->getTglRegistrasi(); ?>">                                        
                        </div>
                    </div>
                    <!-- <div class="form-group">
                            <label for="pt" class="col-lg-3 control-label">Status Registrasi:</label>
                                    <div class="col-lg-6">
                    <input type="text" class="form-control input-sm" name="status" id="status" value="<?= $status->getNamaStatus(); ?>">
                    <input type="hidden" id="idstatus">                                        
                    </div>
                    </div>-->
                    <?php if ($this->sessionutility->isAdministrator()) { ?>
                        <div class="form-group">
                            <label for="pt" class="col-lg-3 control-label">Status:</label>
                            <div class="col-lg-6">
                                <input type="text" class="form-control input-sm" disabled name="status" id="status_ver" value="<?= $objStatus->getNamaStatus(); ?>">
                                <input type="hidden" id="idstatus">                                        
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="pt" class="col-lg-3 control-label">Verifikasi:</label>
                            <div class="col-lg-6">
                                <textarea class="form-control input-sm" name="status" id="keterangan"><?php echo $verifikasi->getKeterangan() ?></textarea>                                        
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="pt" class="col-lg-3 control-label"></label>
                            <div class="col-lg-6">
                                <button class="btn btn-sm btn-success" id="approved" <?php
                                if ($status_verifikasi == '2') {
                                    echo 'disabled="disabled"';
                                }
                                ?>>Approved</button>
                                <button class="btn btn-sm btn-warning" id="disapproved" <?php
                                if ($status_verifikasi == '6') {
                                    echo 'disabled="disabled"';
                                }
                                ?>>Disapproved</button>
                                <a href="<?= base_url() . 'backoffice/kelolaregistrasi/exportverifikasi/' . $registrasi->getIdRegistrasi() ?>" target="_new" class="btn btn-sm btn-info">Export</a>
                            </div>
                        </div>
                    <?php } ?>
                </form>
            </div>
            
            

            <div class="row-fluid">
                     <h3>Data Program Studi yang diusulkan</h3>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead class=" thead-dark">
                            <tr class="">

                                <th class="text-center">Nama Program Studi</th> 			                               
                                <th class="text-center">Jenjang</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            //print_r($pdpt);
                            $sql = "select * from registrasi_prodi where id_registrasi='".$registrasi->getIdRegistrasi()."'";
                            $resultprodi=$this->db->query($sql);
                            if ($resultprodi->num_rows()>0) {
                                ?>

                                <?php foreach ($resultprodi->result() as $row) { ?>
                                    <tr>
                                        <td class="text-center"><?= $row->nama_prodi; ?></td>
                                        <td class="text-center"><?= $row->jenjang; ?></td>
                                    </tr>
                                <?php }
                                ?>

                            <?php } ?>
                        </tbody>
                    </table>
                </div>
                
                
                
                
                
                <h3>Data Pelaporan Pdpt</h3>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead class=" thead-dark">
                            <tr class="">

                                <th class="text-center">Tahun Pelaporan</th> 			                               
                                <th class="text-center">Persentasi</th>

                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            //print_r($pdpt);
                            if (is_object($pdpt)) {
                                ?>

                                <?php foreach ($pdpt as $objpdpt) { ?>
                                    <tr>
                                        <td class="text-center"><?= $objpdpt->getTahunLapor() ?></td>
                                        <td class="text-center"><?= round($objpdpt->getPersentasi()) ?>%</td>
                                    </tr>
                                <?php }
                                ?>

                            <?php } ?>
                        </tbody>
                    </table>
                </div>
                <h3>Usulan Perubahan PT: <label id="status_perubahan"><?= $ubah_pt ?></label>
                </h3>
                <h3>Rencana Usulan Perubahan PT: <label id="status_perubahan"><?= $rencana_ubah_pt ?></label>
                </h3>
                <input type="hidden" id="penyelenggara_id" value="<?= $penyelenggara_id; ?>">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead class=" thead-dark">
                            <tr class="">
                                <th>#</th>
                                <th class="text-center">Nama Dokumen</th> 			                               
                                <th class="text-center">Tersedia</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $dokumen_registrasi = new DokumenRegistrasi();
                            $res_dok_reg = $dokumen_registrasi->getByRelated('registrasi', 'id_registrasi', $registrasi->getIdRegistrasi(), '0', '0');
                            $i = 1;
                            if ($res_dok_reg->num_rows() > 0) {

                                foreach ($res_dok_reg->result() as $row) {
                                    $dokumen = new Dokumen();
                                    $params['id_form'] = $row->id_form;
                                    $params['skema'] = $registrasi->getSchema();
                                    $params['periode'] = $registrasi->getPeriode();
                                    $dokumen->getByArray($params);
                                    ?>
                                    <tr>
                                        <td><?= $i ?></td>
                                        <td><?= $dokumen->getFormName() ?></td>
                                        <td>
                                            <?php
                                            $ischecked = '';
                                            $label = '-';
                                            if ($dokumen->getIdForm() != '') {
                                                $label = 'Ya';
                                            } else {
                                                $label = 'Tidak';
                                            }
                                            if ($row->verifikasi == 'y') {
                                                $ischecked = 'checked';
                                                $label = 'Verified';
                                            }
                                            ;
                                            ?>
                                            <input type="checkbox" id="<?= $row->id_upload ?>" class="tersedia" <?= $ischecked; ?> > 
                                            <label id="lbl_<?= $row->id_upload ?>"><?= $label; ?>                                                                       
                                            </label>
                                        </td>
                                        <td>
                                            <?php $item = array('F10', 'F11', 'F12', 'F13'); ?>
                                            <?php if (in_array($row->id_form, $item)) { ?>
                                                <a href="<?= base_url() . 'backoffice/kelolaevaluasi/downloaddocument/' . $row->id_upload ?>"><i class=" fa fa-download"></i></a>
                                            <?php } else { ?>
                                                <a href="#" role="button" id="<?= $row->id_upload ?>" 
                                                   src="<?= base_url() . 'backoffice/kelolaevaluasi/downloaddocument/' . $row->id_upload ?>" class="view" title="View">
                                                    <i class="fa fa-download"></i>
                                                </a>
                                            <?php } ?>
                                        </td>
                                    </tr>
                                    <?php
                                    $i++;
                                }
                            }
                            ?>
                            <?php
                            $dokumen_perbaikan = new DokumenPerbaikan();
                            $dokumen_perbaikan->setSkema($registrasi->getSchema());
                            $dokumen_perbaikan->setPeriode($registrasi->getPeriode());
                            $dokumen_perbaikan->setJnsUsulan($registrasi->getJnsUsulan());
                            $res_dok_per = $dokumen_perbaikan->get('0', '0');
                            //print_r($res_dok_per);
                            foreach ($res_dok_per->result() as $rdp) {
                                ?>
                                <tr>
                                    <td><?= $i ?></td>
                                    <td><?= $rdp->form_name ?></td>
                                    <td></td>
                                    <td>
                                        <?php
                                        $params['id_form'] = $rdp->id_form;
                                        $params['id_registrasi'] = $registrasi->getIdRegistrasi();
                                        $dokper_upload = new DokumenPerbaikanUpload($params);
                                        if ($dokper_upload->getIdUpload() != '') {
                                            ?>
                                            <a href="<?= base_url() . 'backoffice/kelolaevaluasi/downloaddocumentperbaikan/' . $registrasi->getIdRegistrasi() . '/' . $rdp->id_form ?>"><i class="fa fa-download"></i></a> 
                                        <?php } else { ?>
                                            <label class="badge-pill badge-danger">File Tidak Tersedia</label>
                                        <?php } ?>
                                    </td>
                                </tr>
                                <?php
                                $i++;
                            }
                            ?>
                        </tbody>
                    </table>
                    <table class="table table-striped">
                        <thead class="thead-dark">
                            <tr>
                                <th>Id Registrasi</th>
                                <th>Referensi</th>
                                <th>Nama File</th>                    
                                <th>Tgl Upload</th>
                                <th>Revisi</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $rekapitulasi_berita = new RekapitulasiBeritaAcara();
                            $rekapitulasi_berita->setIdRegistrasi($registrasi->getIdRegistrasi());
                            $res_rekap = $rekapitulasi_berita->get('0', '0');
                            $this->load->model('Dokumenpresentasi');

                            if ($res_rekap->num_rows() > 0) {
                                //print_r($res_rekap->result());
                                foreach ($res_rekap->result() as $row) {
                                    $dok_pres = new DokumenPresentasi();
                                    $dok_pres->getBy('id_jns_file', $row->id_jns_file);
                                    ?>
                                    <tr>
                                        <td><?= $row->id_registrasi ?></td>
                                        <td><?= $row->referensi ?></td>
                                        <td><?= $dok_pres->getNamaFile() ?></td>

                                        <td><?= $row->tgl_upload ?></td>
                                        <td><?= $row->revisi ?></td>
                                        <td>
                                            <a href="<?= base_url() . 'backoffice/kelolaevaluasi/downloadfilepresentasi/' . $row->id . '/' . $row->id_jns_file ?>" target="new" title="Unduh">
                                                <i class="fa fa-download"></i><a/>
                                                <a href="<?= base_url() . 'backoffice/kelolaevaluasi/removedokumen/' . $row->id . '/' . $row->id_registrasi ?>" 
                                                   target="new" title="Delete" onclick="return deleteDocument()">
                                                    <i class="fa fa-remove"></i><a/>
                                                    </td>
                                                    </tr>
                                                    <?php
                                                }
                                            }
                                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>



<div class="modal fade" id="modal_file" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title" id="exampleModalLabel">Dokumen</h4>
            </div>
            <div class="modal-body">
                <div class="container">
                    <iframe id="pdfview" src="" style="width:812px; height:700px;" frameborder="0"></iframe>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>		        
            </div>
        </div>
    </div>
</div>
                                            		
