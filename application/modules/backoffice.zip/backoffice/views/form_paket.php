
<script type="text/javascript">
    $("document").ready(function () {
        
        $(function () {
            $("#hide_form").hide();
        });
        
        $("#supplier").autocomplete({
            minLength: 3,
            source: function (req, add) {
                $.ajax({
                    url: '<?php echo base_url() . 'backoffice/kelolapaket/autocompletesupplier/'; ?>',
                    dataType: 'json',
                    type: 'POST',
                    data: req,
                    success: function (data) {
                        if (data.response === 'true') {
                            add(data.message);
                        }
                    }
                });
            },
            select: function (event, ui) {
                var kdeval = ui.item.kode;
                $("#id_supplier").val(kdeval);
                //alert(kdeval);

            }
        });

        $("#perguruan_tinggi").autocomplete({
            minLength: 3,
            source: function (req, add) {
                $.ajax({
                    url: '<?php echo base_url() . 'backoffice/kelolapaket/autocompletept/'; ?>',
                    dataType: 'json',
                    type: 'POST',
                    data: req,
                    success: function (data) {
                        if (data.response === 'true') {
                            add(data.message);
                        }
                    }
                });
            },
            select: function (event, ui) {
                var idreg = ui.item.kode;
                $("#id_registrasi").val(idreg);
                //alert(kdeval);
                /*$.ajax({
                    url: '<?php echo base_url() . 'backoffice/kelolapaket/autocompletebarang/'; ?>',
                    dataType: 'json',
                    type: 'POST',
                    data: {idregistrasi:idreg},
                    success: function (result) {
                        if (result.response === 'true') {
                            for(var x=0;x<result['message'].length;x++){
                                    $('#nama_barang').empty(); // kosongkan dahulu combobox yang ingin diisi datanya
                                     $('#nama_barang').append('<option>-Pilih-</option>'); // buat pilihan awal pada combobox
                                     for(var x=0;x<result['message'].length;x++){
                                            // berikut adalah cara singkat untuk menambahkan element option pada tag <select>
                                            $('#nama_barang').append($('<option></option>').val(result['message'][x].value).text(result['message'][x].label));
                                     }

                            }
                        }
                    }
                });*/
            }
        });

        $("#_nama_barang").autocomplete({
            minLength: 3,
            source: function (req, add) {
                $.ajax({
                    url: '<?php echo base_url() . 'backoffice/kelolapaket/autocompletebarang/'; ?>',
                    dataType: 'json',
                    type: 'POST',
                    data: req,
                    success: function (data) {
                        if (data.response === 'true') {
                            add(data.message);
                        }
                    }
                });
            },
            select: function (event, ui) {
                var kdeval = ui.item.kode;
                $("#id_item").val(kdeval);
                //alert(kdeval);

            }
        });

        $('#save_paket').click(function () {
            var formData = new FormData($('#form_paket')[0]);
            formData.append('flaginsert',$("#flaginsert").val());
            var _url = $("#form_paket").attr('action');
            //alert(_url);
            $.ajax({
                url: _url, //Server script to process data
                type: 'POST', dataType: "JSON",
                xhr: function () {  // Custom XMLHttpRequest
                    var myXhr = $.ajaxSettings.xhr();
                    if (myXhr.upload) { // Check if upload property exists
                        //myXhr.upload.addEventListener('progress', progressHandlingFunction, false); // For handling the progress of the upload
                    }
                    return myXhr;
                },
                //Ajax events
                //beforeSend: beforeSendHandler,
                success: function (result) {
                    //alert(result.response);
                    if (result.response === "true") {
                        alert("Update sucessfull!");
                        $("#flaginsert").val(result.flaginsert);
                        $("#id_paket").val(result.id_paket);

                    } else if (result.response === "false") {
                        alert(result.error);
                    } else {
                        alert("Update fail!");
                    }
                },
                //error: errorHandler,
                // Form data
                data: formData,
                //Options to tell jQuery not to process data or worry about content-type.
                cache: false,
                contentType: false,
                processData: false
            });
        });

        $('#upload_detail').click(function () {
            var formData = new FormData($('#form_detail')[0]);
            formData.append('id_paket',$("#id_paket").val());
            formData.append('no_kontrak', $("#no_kontrak").val());
            formData.append('kontrak_adendum', $("#kontrak_adendum").val());
            //formData.append('id_item', $("select[id='nama_barang'] option:selected").val());*/
            //var id_pak = $("#id_paket").val();
            //var id_reg = $("#id_registrasi").val();
            var _url = $("#form_detail").attr('action');
            //alert(_url);
            $.ajax({
                url: _url, //Server script to process data
                type: 'POST', dataType: "JSON",
                xhr: function () {  // Custom XMLHttpRequest
                    var myXhr = $.ajaxSettings.xhr();
                    if (myXhr.upload) { // Check if upload property exists
                        //myXhr.upload.addEventListener('progress', progressHandlingFunction, false); // For handling the progress of the upload
                    }
                    return myXhr;
                },
                //Ajax events
                //beforeSend: beforeSendHandler,
                success: function (result) {
                    //alert(result.response);
                    if (result.response === "true") {
                        alert("Update sucessfull!");
                        //$("#flag_detail").val(result.flaginsert);
                        //$("#id_detail_paket").val(result.id_detail_paket);
                        $("#id_item").val(result.id_item);
                        $("#tbl_detail tbody").remove();
                        $("#tbl_detail").append("<tbody></tbody>");
                        for(var x=0;x<result['record_detail'].length;x++){
                            $("#tbl_detail tbody").append(
                                    "<tr>" + 
                                    "<td>" + x + "</td>" +
                                    "<td>" + result['record_detail'][x].no_kontrak + "</td>" +
                                    "<td>" + result['record_detail'][x].adendum_ke + "</td>" +
                                    "<td>" + result['record_detail'][x].id_registrasi + "</td>" +
                                    "<td>" + result['record_detail'][x].kdpti + "</td>" +
                                    "<td>" + result['record_detail'][x].nama_barang + "</td>" + 
                                    "<td>" + result['record_detail'][x].merk + "</td>" + 
                                    "<td>" + result['record_detail'][x].type + "</td>" + 
                                    "<td>" + result['record_detail'][x].volume + "</td>" +                                      
                                    "<td>" + result['record_detail'][x].hps + "</td>" + 
                                    "<td>" + result['record_detail'][x].total + "</td>" + 
                                    /*"<td>" + "<a href='#' class='remove_rl' id='" + result['record_detail'][x].id_detail_paket + "'>" +
                                    "<i class='glyphicon glyphicon-remove'></i></a></td>" +*/
                                    "</tr>");

                        }
                    } else if (result.response === "false") {
                        alert(result.error);
                    } else {
                        alert("Update fail!");
                    }
                },
                //error: errorHandler,
                // Form data
                data: formData,
                //Options to tell jQuery not to process data or worry about content-type.
                cache: false,
                contentType: false,
                processData: false
            });
        });


        $("#tgl_kontrak").datepicker({
            dateFormat: "yy-mm-dd",
            changeYear: true
        });

        $("#tgl_akhir_kontrak").datepicker({
            dateFormat: "yy-mm-dd",
            changeYear: true
        });


        $("a.tab").click(function () {
            // switch all tabs off  

            $(".active").removeClass("active");
            // switch this tab on  
            $(this).addClass("active");
            // slide all elements with the class 'content' up  
            $(".tab_content").hide(); //slideUp;  
            //var maxY = window.scrollMaxY;
            //window.scrollByPages(1);
            // Now figure out what the 'title' attribute value is and find the element with that id.  Then slide that down.  
            var content_show = $(this).attr("title");
            $("#" + content_show).show();
            $("#" + content_show).focus();
            return false;
        });

        $('#myTab a:first').tab('show');
    });

</script>
<div class="card">
    <h2 class="">
        Tambah Paket Barang
    </h2>

    <ul class="nav nav-tabs" role="tablist" id="myTab">

        <li class="nav-item">
            <a href="#paket" class="nav-link active" aria-controls="paket" role="tab" data-toggle="tab">Data Paket</a>
        </li>

        <li class="nav-item">
            <a href="#detail_paket" class="nav-link" aria-controls="detail_paket" role="tab" data-toggle="tab">Detail Paket</a>
        </li>        

    </ul>

    <div class="tab-content">
        <div id="paket" role="tabpanel" class="tab-pane active">

            <div class="card-body" >
                <?php if (validation_errors() != '') { ?>                    
                    <div class="alert alert-danger alert-dismissible" role="alert">
                        <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                        <strong><?php echo validation_errors(); ?></strong>
                    </div>
                <?php } ?>                    
                <div class="">
                    <form class="form-horizontal" id="form_paket" method="post" action="<?= base_url() . 'backoffice/kelolapaket/save/' ?>">
                        <div class="form-group">
                            <label class="col-lg-3 control-label lbl-color" >ID Paket:</label>

                            <div class="col-lg-8">
                                <input type="text" id="id_paket" name="id_paket" class="form-control input-sm" value="<?php if(isset($paket)){echo $paket->getId();} ?>" disabled="disabled">
                                
                            </div>
                        </div>
						
						<div class="form-group">
                            <label class="col-lg-3 control-label lbl-color" >Nama Paket:</label>

                            <div class="col-lg-8">
                                <input type="text" id="nama_paket" name="nama_paket" class="form-control input-sm" value="<?php if(isset($paket)){echo $paket->getNamaPaket();} ?>">
                                <input type="hidden" id="flaginsert" name="flaginsert" value="<?php if(isset($paket)){echo '1';}else{ echo '0';} ?>">
                                
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-lg-3 control-label lbl-color" >Supplier:</label>
                            <div class="col-lg-8">
                                <?php if(isset($paket)){$supplier = $paket->getSupplier();}?>
                                <input type="text" id="supplier" name="supplier" class="form-control input-sm" value="<?php if(isset($supplier)){echo $supplier->getNamaSupplier();} ?>">
                                <input type="hidden" id="id_supplier" name="id_supplier" value="<?php if(isset($supplier)){echo $supplier->getId();} ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-lg-3 control-label lbl-color" >No Kontrak:</label>
                            <div class="col-lg-8">
                                <input type="text" id="no_kontrak" name="no_kontrak" class="form-control input-sm" value="<?php if(isset($paket)){echo $paket->getNoKontrak();} ?>">                      
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-lg-3 control-label lbl-color" >Tgl Kontrak:</label>
                            <div class="col-lg-8">
                                <input type="text" id="tgl_kontrak" name="tgl_kontrak" class="form-control input-sm" value="<?php if(isset($paket)){echo $paket->getTglKontrak();} ?>">

                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-lg-3 control-label lbl-color" >Tgl Akhir Kontrak:</label>
                            <div class="col-lg-8">
                                <input type="text" id="tgl_akhir_kontrak" name="tgl_akhir_kontrak" class="form-control input-sm" value="<?php if(isset($paket)){echo $paket->getTglAkhirKontrak();} ?>">

                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-lg-3 control-label lbl-color" >Adendum:</label>                    
                            <div class="col-lg-8">
                                <?php
                                $opt_adendum = array('-' => '-Pilih-', 'Yes' => 'Yes', 'No' => 'No');
                                $sel_adendum = '-';
                                if(isset($paket)){$sel_adendum = $paket->getAdendum();}
                                echo form_dropdown('adendum', $opt_adendum, $sel_adendum, 'class="form-control" id="adendum"');
                                ?>

                            </div>
                        </div>
                        <div class="form-group">
                            <label class="col-lg-3 control-label lbl-color" >Bukti Kontrak:</label>                    
                            <div class="col-lg-8">
                                <?php   if(isset($paket)){?>
                                
                                <input type="file" id="userfile" name="userfile" class="form-control"  value="<?=$paket->getFileBuktiKontrak() ?>"> 
                                <?php   }else{ ?>
                                <input type="file" id="userfile" name="userfile" class="form-control"  value="">                                       
                                <?php   } ?>
                            </div>
                        </div>
                        <div class="modal-footer">
                        <div class="form-group">
                            <div class="">
                                <a href="#" id="save_paket" class="btn btn-success btn-sm"><i class="glyphicon glyphicon-floppy-disk"></i> Save</a>
                                <button type="submit" id="cancel_paket" class="btn btn-success btn-sm"><i class="glyphicon glyphicon-ok"></i> OK</button>
                            </div>
                        </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div id="detail_paket" role="tabpanel" class="tab-pane">
            <div class="card-body">
                <form action="<?= base_url() . 'backoffice/kelolapaket/savedetail/' ?>" id="form_detail">
                    
                    <div class="">
                        <div class="form-horizontal" >
                            <div class="form-group">
                                <label class="col-lg-3 control-label lbl-color" >Adendum Ke:</label>
                                <div class="col-lg-8">
                                    <input type="text" id="kontrak_adendum" name="kontrak_adendum" class="form-control input-sm" 
                                           value="">

                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-lg-3 control-label col-md-1" for="instansi">File:</label>
                                
                                    <input type="hidden" id="flag_detail" name="flag_detail" value="0">
                                    <input type="hidden" id="id_detail_paket" name="id_detail_paket" value="0">
                                    <input type="hidden" id="id_registrasi" name="id_registrasi" value="">
                                    
                                    <div class="col-lg-8">
                                        <input type="file" id="userfile" name="userfile" class="form-control input-sm">

                                    </div>
                                    
                                
                            </div>
                            <div class="form-group">
                                <label class="col-lg-3 control-label" for="instansi"></label>
                                <div class="col-lg-8">
                                    <a href="#" id="upload_detail" class="btn btn-primary btn-sm">
                                        <i class="glyphicon glyphicon-upload"></i> Add</a>                      
                                </div>
                            </div>
                        
                    </div>
                    <div class="modal-footer">
                        
                    </div>
                    </div>
                </form>

                <div class="form-group">

                </div>
                <table class="table table-striped table-responsive" id="tbl_detail">
                    <thead class="tbl-head">
                        <tr class="bg-success" >
                            <th class="text-center">No</th> 
                            <th class="text-center">No Kontrak</th>
                            <th class="text-center">Adendum Ke</th>
                            <th class="text-center">ID Registrasi</th> 
                            <th class="text-center">Nama PT</th> 
                            <th class="text-center">Nama Barang</th>                 
                            <th class="text-center">Merk</th>
                            <th class="text-center">Type</th>                
                            <th class="text-center">Volume</th>
                            <!--<th class="text-center">Biaya Kirim</th>-->
                            <th class="text-center">Harga</th>
                            <th class="text-center">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            if(isset($detail_paket) && $detail_paket->num_rows()>0){
                                $i=1;
                                foreach ($detail_paket->result() as $row){
                        ?>
                        <tr>
                            <td><?= $i;?></td>
                            <td><?= $row->no_kontrak;?></td>
                            <td><?= $row->adendum_ke;?></td>
                            <td><?= $row->id_registrasi; ?></td>
                            <?php
                                $registrasi = new Registrasi($row->id_registrasi);
                                $pti = $registrasi->getPti();
                                $barang = new Barang($row->id_item);
                            ?>
                            <td><?= $pti->getNmPti(); ?></td>
                            <td><?= $barang->getNmBarang(); ?></td>
                            <td><?= $row->merk; ?></td>
                            <td><?= $row->type; ?></td>
                            <td><?= $row->volume; ?></td>
                            <!--<td><?= $row->biaya_kirim; ?></td>-->
                            <td><?= $row->hps; ?></td>
                            <td><?= $row->total; ?></td>
                            
                        </tr>
                                <?php   $i++;
                                }
                            }
                        ?>
                    </tbody>				
                </table>
            </div>

        </div>
    </div><!-- end tab-content -->
</div>    

<?php
//include 'form_hibah.php';
?>