
<script type="text/javascript" >
    $("document").ready(function () {
        /*$("#tglawal").datepicker({
            dateFormat: "yy-mm-dd",
            changeYear: true
        });

        $("#tglakhir").datepicker({
            dateFormat: "yy-mm-dd",
            changeYear: true
        });*/



        $("#filter").change(function () {
            var x = document.getElementById("filter").selectedIndex;
            var y = document.getElementById("filter").options;
            //alert(y[x].value);
            if (y[x].value === 'semua') {
                $("#keyword").val("all");
            } else if (y[x].value === 'jns_usulan') {
                //$("#keyword").attr("class",'complete');
            }

        });


        $(document.body).on("click", ".pleno", function ()
        {
            var id_reg = $(this).attr('id');
            var status = $("#" + id_reg).is(":checked");

            //alert(status);
            if (confirm("Anda ingin mengumumkan usulan ini ?")) {

                $.ajax
                        ({
                            type: "POST",
                            url: "<?php echo base_url() . 'backoffice/kelolaregistrasi/publishverifikasi/' ?>" + id_reg + "/" + status,
                            success: function (msg)
                            {
                                alert(msg);
                                //$("#"+noevaluasi).Attr("checked","true");
                            }
                        });

            } else {
                if (status) {
                    $("#" + noevaluasi).removeAttr("checked");
                } else {
                    $("#" + noevaluasi).prop("checked", true);
                }
            }
        });



    });


</script>
<script language=javascript>
    function activation()
    {
        var answer = confirm("Registrasi usulan ini ?")
        if (answer) {
            document.messages.submit();
        }

        return false;

    }
</script>  
<h2 class="page-header">Daftar Usulan Teregistrasi</h2>
<div class="card">
    <div class="card-header text-justify">
        
        <i class="fa fa-list"></i>
    </div>
    <div class="card-body">
        <div class="row-fluid">
            <div class="table-responsive">
                <table class="table table-condensed table-striped table-bordered">
                    <thead class="">
                        <tr class="" >
                            <th>No</th>
                            <th class="text-center">Id Registrasi</th> 
                            <th class="text-center">Yayasan</th> 
                            <th class="text-center">Perguruan Tinggi</th>                 
                            <th class="text-center">Tgl Registrasi</th>
                            <th class="text-center">Periode</th>
                            <th class="text-center">Schema</th>
                            <th class="text-center">Status</th>                
                            <th class="text-center">Publish</th>
                            <th class="text-center">Action</th>
                        </tr>
                        <tr class="bg-light">
                    <form method="post" action="<?= base_url() ?>backoffice/kelolaregistrasi/find/">
                        <th>Filter:</th>
                        <th><input type="text" id="keyword" name="id_registrasi" class="form-control form-control-sm"></th>
                        <th><input type="text" id="keyword" name="yayasan" class="form-control form-control-sm"></th>
                        <th><input type="text" id="keyword" name="pti" class="form-control form-control-sm"></th>
                        <th><input type="text" id="keyword" name="tgl_registrasi" class="form-control form-control-sm"></th>
                        <th>
                            <?php
                            echo form_dropdown('periode', $periode, '', 'class="form-control form-control-sm" id="periode"');
                            ?>
                        </th>
                        <th>
                            <?php
                            echo form_dropdown('schema', $skema, '', 'class="form-control form-control-sm" id="schema"');
                            ?>
                        </th>
                        <th>
                            <?php
                            echo form_dropdown('status_registrasi', $status_registrasi, '', 'class="form-control form-control-sm" id="status_registrasi"');
                            ?>
                        </th>
                        <th>
                            <?php
                            echo form_dropdown('publish_verifikasi', $publish_verifikasi, '', 'class="form-control form-control-sm" id="publish_verifikasi"');
                            ?>
                        </th>
                        <th>
                            <button type="submit" name="find" class="btn btn-primary btn-sm" value="find">
                                <i class="fa fa-search"></i>
                            </button>
                        </th>
                    </form>
                    </tr>
                    </thead>
                    <tbody>          
                        <?php //print_r($registrasi)?>                
                        <?php
                        if (isset($registrasi) && is_object($registrasi)) {
                            $segment = $this->uri->segment(4, 0);
                            $user = $this->session->userdata('userid');
                            $i = $segment + 1;
                            if ($i == '') {
                                $i = 1;
                            }
                            foreach ($registrasi->result() as $obj) {
                                $reg = new Registrasi($obj->id_registrasi);
                                //$account = $reg->getAccount();
                                //$yayasan = $account->getYayasan();
                                $pt = $reg->getPti();
                                $nm_pti = '';
                                if ($pt->getNmPti()) {
                                    $nm_pti = $pt->getNmPti();
                                }
                                $yayasan = $reg->getPenyelenggara();
                                $status = $reg->getStatusRegistrasi();
                                $nama_status = '';
                                if (is_object($status)) {
                                    $nama_status = $status->getNamaStatus();
                                }
                                $nmyayasan = '-';
                                if (is_object($yayasan)) {
                                    $nmyayasan = $yayasan->getNamaPenyelenggara();
                                }
                                $publish = 'no';
                                $verifikasi = $reg->getVerifikasi();
                                $isVerified = '';
                                $statusVerifikasi = '';
                                //print_r($verifikasi);
                                if (is_object($verifikasi)) {
                                    $publish = $verifikasi->getPublish();
                                    $statusVerifikasi = $verifikasi->getIdStatusRegistrasi();
                                    if ($verifikasi->getIdRegistrasi() != '') {
                                        $isVerified = 'Verified';
                                    } else {
                                        
                                    }
                                }
                                ?>
                                <tr class="tbl-row">

                                    <td><?= $i ?></td>
                                    <td><?= $obj->id_registrasi ?></td>
                                    <td><?= $nmyayasan ?></td>
                                    <td><?= $nm_pti; ?></td>
                                    <td><?= $reg->getTglRegistrasi(); ?></td>
                                    <td><?= $obj->periode; ?></td>
                                    <td><?= $obj->skema; ?></td>
                                    <td><?= $nama_status; ?></td>
                                    <td>
                                        <?php
                                        if ($publish == 'yes') {
                                            if ($isVerified != '') {
                                                ?>
                                                <input type="checkbox" id="<?= $obj->id_registrasi ?>" class="pleno" checked="checked"> 
                                                <?php
                                                if ($verifikasi->getIdStatusRegistrasi() == '2') {
                                                    echo "Approved";
                                                } else {
                                                    echo "Disapproved";
                                                }
                                                ?>
                                                </input>
                                            <?php } else { ?>
                                                <input type="checkbox" id="<?= $obj->id_registrasi ?>" class="pleno" checked="checked"></input>
                                            <?php } ?>
                                            <?php
                                        } else {
                                            if ($isVerified != '') {
                                                ?>
                                                <input type="checkbox" id="<?= $obj->id_registrasi ?>" class="pleno"> 
                                                <?php
                                                if ($statusVerifikasi == '2') {
                                                    echo "Approved";
                                                } else {
                                                    echo "Disapproved";
                                                }
                                                ?>
                                                </input>
                                            <?php } else { ?>
                                                <input type="checkbox" id="<?= $obj->id_registrasi ?>" class="pleno"></input>
                                            <?php } ?>

                                        <?php } ?>
                                    </td>

                                    <td>
                                        <a href="<?= base_url() . 'backoffice/kelolaregistrasi/detail/' . $reg->getIdRegistrasi() ?>" title="Detail Usulan">
                                            <i class="fa fa-list"></i> </a>
                                    </td>
                                </tr>
                                <?php
                                $i++;
                            }
                        }
                        ?>        

                    </tbody>
                </table>
            </div>
            <h4>Total Record: <span class="label label-info"><?= $total_row ?></span></h4>
            <div>
                <?php
                echo $this->pagination->create_links();
                //echo $articles->count();
                ?>
            </div>
        </div>
    </div>

</div>
