
<script type="text/javascript" >
$("document").ready(function(){
    $("#tglawal").datepicker({
		dateFormat:"yy-mm-dd",
                changeYear:true
    });
    
    $("#tglakhir").datepicker({
		dateFormat:"yy-mm-dd",
		changeYear:true
    });
    
    
    
    $("#filter").change(function(){
        var x = document.getElementById("filter").selectedIndex;
        var y = document.getElementById("filter").options;
        //alert(y[x].value);
        if(y[x].value==='semua'){
            $("#keyword").val("all");
        }else if(y[x].value==='jns_usulan'){
            //$("#keyword").attr("class",'complete');
        }

    });        
        
    
    $(document.body).on("click",".pleno",function()
    {
   		var id_reg=$(this).attr('id');
    	var status = $("#"+id_reg).is(":checked");
    	            
    	//alert(status);
        if(confirm("Anda ingin mengumumkan usulan ini ?")){			
		
			$.ajax
			({
				type: "POST",
				url: "<?php echo base_url().'backoffice/kelolaregistrasi/publishverifikasi/'?>"+id_reg+"/"+status,
				success: function(msg)
				{			
					alert(msg);
                    //$("#"+noevaluasi).Attr("checked","true");
				}
			});
                
		}else{
			if(status){
            	$("#"+noevaluasi).removeAttr("checked");
			}else{
				$("#"+noevaluasi).prop("checked", true);
			}
        }    	            
   	});
    
    
        
});


</script>
<script language=javascript>
function activation()
    {
        var answer = confirm("Registrasi usulan ini ?")
        if (answer){
            document.messages.submit();
        }

        return false;  
        
    }
</script>  
<div class="">

    <div class="md-card"><i class="glyphicon glyphicon-tag"></i>
    <h2 class="">
    Daftar Penerimaan Barang
    </h2>
    
    <div class="panel panel-default">
        <div class="panel-heading"><i class="glyphicon glyphicon-search"></i> Pencarian</div>
        <div class="panel-body pnl-bg">
        <form class="form-horizontal" role="form" method="post" action="<?=base_url()?>backoffice/kelolapaket/findterima/">    
            <fieldset>
            
            <div class="form-group">
                <!-- <div class="col-sm-2">
                    <label for="tglakhir" class="">Tgl Awal</label>
                    <input type="text" id="tglawal" name="tglawal" class="form-control input-sm" placeholder="yyyy-mm-dd">                
                </div>

                <div class="col-sm-2">
                    <label for="tglakhir" class="">Tgl Akhir</label>
                    <input type="text" id="tglakhir" name="tglakhir" class="form-control input-sm" placeholder="yyyy-mm-dd">

                </div>-->
            <!--</div>

            <div class="form-group"> 
                <!--<div class="form-group">-->
                    <div class="col-lg-3">
                        <label for="filter" class="">Kriteria Pencarian</label>
                        <?php 
                        	$filter = array(''=>'-Pilih-','nmpti'=>'Nama PT','nama_penyelenggara'=>'Yayasan',
                        			'id_registrasi'=>'No Registrasi','nama_status'=>'Status','all'=>'Semua');
                        	$a_filter = '';
                        	if (isset($selected_filter)){
                        		$a_filter = $selected_filter;
                        	}
                        	?>
                        <?php  echo form_dropdown('filter', $filter,$a_filter,'class="form-control input-sm" id="filter"');?>
                        <!--<select id="filter" class="form-control input-sm">
                            <option>One</option>
                            <option>Two</option>
                        </select>-->
                    </div>
                <!--</div>-->

                <!--<div class="form-group">-->
                    <div class="col-lg-4">
                        <label for="keyword" class="">Kata Kunci</label>
                        <div class="input-group">                                          
                            <input type="text" id="keyword" name="keyword" class="form-control input-sm">
                            <span class="input-group-btn">
                              <button type="submit" name="find" class="btn btn-primary btn-sm" value="find"><i class="glyphicon glyphicon-search glyphicon-white"></i> Find</button>
                              <button type="submit" name="export" id="export" class="btn btn-success btn-sm" value="export"><i class="glyphicon glyphicon-share glyphicon-white"></i> Export</button>
                            </span>
                        </div>
                    </div><!-- /input-group -->
                <!--</div><!-- /.col-lg-6 -->
            </div>
                <h4>Total Record: <span class="label label-info"><?=$total_row?></span></h4>
           
            </fieldset>
        </form>    
        </div>
</div>
    


<div class="row-fluid">
    <div class="table-responsive">
        <table class="table table-condensed table-striped table-bordered">
            <thead class="tbl-head">
              <tr class="bg-success" >
                <th>#</th>
                <th class="text-center">Id Registrasi</th> 
                <th class="text-center">Yayasan</th> 
                <th class="text-center">Perguruan Tinggi</th>                 
                <th class="text-center">Tgl Registrasi</th>
                <th class="text-center">No Kontrak</th>                
                <th class="text-center">Terkirim</th> 
                <th class="text-center">Action</th>
              </tr>
            </thead>
            <tbody>          
<?php //print_r($registrasi)?>                
<?php if(isset($registrasi) && $registrasi != null){ 
	$segment = $this->uri->segment(4,0);
    $user = $this->session->userdata('userid');
    $i = $segment+1;
    if($i==''){
        $i = 1;
    }
    foreach($registrasi->result() as $obj){
    	$reg = new Registrasi($obj->id_registrasi);
        //$account = $reg->getAccount();
        //$yayasan = $account->getYayasan();
        $pt = $reg->getPti();
        $yayasan = $reg->getPenyelenggara();
        $status = $reg->getStatusRegistrasi();
        $nmyayasan = '-';
        if(is_object($yayasan)){
        	$nmyayasan = $yayasan->getNamaPenyelenggara();
        }        
        $detail_paket_hibah = new DetailPaketHibah();
        $detail_paket_hibah->setKdPti($reg->getKdPti());
        $detail_paket_hibah->getBy('kdpti', $reg->getKdPti());
        
        
?>
        <tr class="tbl-row">
        
          <td><?=$i?></td>
          <td><?= $obj->id_registrasi?></td>
          <td><?= $nmyayasan ?></td>
          <td><?= $pt->getNmPti(); ?></td>
          <td><?= $reg->getTglRegistrasi(); ?></td>
          <td><?= $detail_paket_hibah->getNoKontrak() ?></td>
          <td>
          	<a href="<?= base_url().'monitoring/monitoring/listbarang/'.$reg->getKdPti()?>" title="Detail Paket">
                  
                  <div class="progress">
                      <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="<?=number_format($detail_paket_hibah->getPercentCompleted(), 2);?>" aria-valuemin="0" aria-valuemax="100" 
                         style="width: <?=number_format($detail_paket_hibah->getPercentCompleted(), 2);?>%;">
                       
                    </div>
                  </div>
                    <?= number_format('0', 2).'%'; ?>
                </a>
          </td>
                     
          <td>
            <a href="<?= base_url().'backoffice/kelolapaket/getForm/'.$reg->getKdPti()?>" title="Berita Acara">
                <i class="glyphicon glyphicon-list"></i> </a>
            <!--<a href="<?= base_url().'backoffice/kelolapaket/getBuktiTerima/'.$reg->getKdPti()?>" title="Bukti Terima">
                <i class="glyphicon glyphicon-import"></i> </a>
            <a href="<?= base_url().'backoffice/kelolapaket/getFotoBarang/'.$reg->getKdPti()?>" title="Foto Barang">
                <i class="glyphicon glyphicon-picture"></i> </a>-->
          </td>
        </tr>
<?php      $i++;
    }
}?>        
        
      </tbody>
    </table>
    </div>
    <div>
        <?php 
            echo $this->pagination->create_links(); 
            //echo $articles->count();
        ?>
    </div>
    
</div>
</div>
</div>