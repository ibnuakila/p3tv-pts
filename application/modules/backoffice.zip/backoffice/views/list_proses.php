
<script type="text/javascript" >
    $("document").ready(function () {
        $("#tglawal").datepicker({
            dateFormat: "yy-mm-dd",
            changeYear: true
        });

        $("#tglakhir").datepicker({
            dateFormat: "yy-mm-dd",
            changeYear: true
        });

        $("#tglawal2").datepicker({
            dateFormat: "yy-mm-dd",
            changeYear: true
        });

        $("#tglakhir2").datepicker({
            dateFormat: "yy-mm-dd",
            changeYear: true
        });

        $("#filter").change(function () {
            var x = document.getElementById("filter").selectedIndex;
            var y = document.getElementById("filter").options;
            //alert(y[x].value);
            if (y[x].value === 'semua') {
                $("#keyword").val("all");
            } else if (y[x].value === 'jns_usulan') {
                //$("#keyword").attr("class",'complete');
            }

        });

        $("#chevrondown").click(function () {
            $("#prosesverifikasi").animate({
                height: 'togle'
            });
        });

        $("#proses").click(function () {
            var x = confirm("Proses data terverifikasi ?");
            if (x) {
                var tgl1 = $("#tglawal2").val();
                var tgl2 = $("#tglakhir2").val();
                $.post("<?php echo base_url() . 'evapro/registrasiprodi/procesverification' ?>",
                        {
                            tglawal: tgl1,
                            tglakhir: tgl2
                        },
                        function (data, status) {
                            alert(data + "\nStatus: " + status);
                            document.location.reload();
                        });
            }
        });

        $("#keyword").autocomplete({
            minLength: 3,
            source: function (req, add) {
                var text = $("select[name='filter'] option:selected").text();

                if (text === 'Jenis Usulan') {
                    $.ajax({
                        url: '<?php echo base_url() . 'evapro/registrasiprodi/autocompletejenisusulan/'; ?>',
                        dataType: 'json',
                        type: 'POST',
                        data: req,
                        success: function (data) {
                            if (data.response == 'true') {
                                add(data.message);
                            }
                        }
                    });
                }
            },
            select: function (event, ui) {
                var nama = ui.item.nama_usulan;
                $("#keyword").val(nama);
                //alert(kdeval);

            }
        });

    });


</script>
<script language=javascript>
    function activation()
    {
        var answer = confirm("Registrasi usulan ini ?")
        if (answer) {
            document.messages.submit();
        }

        return false;

    }
</script>  



<h2 class="page-header">Usulan Dalam Proses Penilaian</h2>
<div class="card">
    <div class="card-header text-justify">

        <i class="fa fa-list"></i>
    </div>
    <div class="card-body">
        <div class="row-fluid">
            <div class="table-responsive">
                <table class="table table-condensed table-striped table-bordered">
                    <thead class="">
                        <tr class="" >
                            <th>#</th>
                            <th class="text-center">Id Registrasi</th>
                            <th class="text-center">Yayasan</th> 
                            <th class="text-center">Perguruan Tinggi</th>
                            <th class="text-center">Jns Usulan</th> 
                            <th class="text-center">Evaluator</th>
                            <th class="text-center">Tgl Penugasan</th>
                            <th class="text-center">Tgl Expire</th>
                            <th class="text-center">Revisi</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Action</th>
                        </tr>
                        <tr class="bg-light">
                    <form method="post" action="<?= base_url() ?>backoffice/kelolaproses/find/">
                        <th>#</th>
                        <th><input type="text" id="id_registrasi" name="id_registrasi" class="form-control form-control-sm"></th>
                        <th><input type="text" id="yayasan" name="yayasan" class="form-control form-control-sm"></th>
                        <th><input type="text" id="pti" name="pti" class="form-control form-control-sm"></th>                        
                        <th>
                            <?php
                            echo form_dropdown('jns_usulan', $jns_usulan, '', 'class="form-control form-control-sm" id="jns_usulan"');
                            ?>
                        </th>
                        <th><input type="text" id="evaluator" name="evaluator" class="form-control form-control-sm"></th>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th>
                            <?php
                            echo form_dropdown('status_proses', $status_proses, '', 'class="form-control form-control-sm" id="status_registrasi"');
                            ?>
                        </th>

                        <th>
                            <button type="submit" name="find" class="btn btn-primary btn-sm" value="find">
                                <i class="fa fa-search"></i>
                            </button>
                        </th>
                    </form>
                    </tr>
                    </thead>
                    <tbody>          

                        <?php
                        if (isset($proses) && $proses != null) {
                            $segment = $this->uri->segment(4, 0);
                            if (!is_numeric($segment)) {
                                $segment = $this->uri->segment(6, 0);
                            }
                            $user = $this->session->userdata('userid');
                            $i = $segment + 1;
                            if ($i == '') {
                                $i = 1;
                            }
                            //print_r($proses->result());
                            foreach ($proses->result() as $obj) {
                                $pro = new Proses($obj->id_proses);
                                $reg = $pro->getRegistrasi();
                                $jenis_usulan = new JenisUsulan($reg->getJnsUsulan());
                                $evaluasi = $pro->getEvaluasi();
                                $pt = $reg->getPti();
                                $nmyayasan = '-';
                                $nmpti = '';
                                $penyelenggara = $reg->getPenyelenggara();
                                if (is_object($penyelenggara)) {
                                    $nmyayasan = $penyelenggara->getNamaPenyelenggara();
                                }
                                $status = $pro->getStatusProses();
                                $stat_eval = '';
                                $skor = '';
                                //print_r($evaluasi);
                                if (is_object($evaluasi)) {
                                    $status_reg = $evaluasi->getStatusRegistrasi();
                                    if (!is_null($status_reg)) {
                                        $stat_eval = $status_reg->getNamaStatus();
                                        $skor = $evaluasi->getSkor();
                                    }
                                }
                                if (!is_null($pt)) {
                                    $nmpti = $pt->getNmPti();
                                }
                                $evaluator = new Evaluator($pro->getIdEvaluator());
                                ?>
                                <tr class="tbl-row <?php
                                if ($status->getIdStatusProses() == '4') {
                                    echo 'danger';
                                }
                                ?>">

                                    <td><?= $i ?></td>
                                    <td><?= $reg->getIdRegistrasi(); ?></td>
                                    <td><?= $nmyayasan; ?></td>
                                    <td><?= $nmpti; ?></td>
                                    <td><?= $jenis_usulan->getNmUsulan(); ?></td>
                                    <td><?= $evaluator->getNmEvaluator(); ?></td>
                                    <td><?= $pro->getTglKirim(); ?></td>
                                    <td><?= $pro->getTglExpire(); ?></td>
                                    <td><?= $pro->getRevisi();?></td>
                                    <td>
                                        <?php if($pro->getIdStatusProses()==4){?>
                                        <div class="text-danger"><?= $status->getNamaStatus(); ?></div>
                                        <?php }else{ ?>
                                        <div class="text-primary"><?= $status->getNamaStatus(); ?></div>
                                        <?php }?>
                                    </td>          
                                    <td>
                                        <?php
                                        if ($this->sessionutility->isAdministrator()) {
                                            ?>
                                                      <!--<a href="<?= base_url() . 'backoffice/kelolaevaluasi/view/' . $reg->getIdRegistrasi() ?>" title="View">
                                                        <i class="fa fa-file"></i> </a>-->
                                            <a href="<?= base_url() . 'backoffice/kelolapenugasan/edit/' . $pro->getIdProses() ?>" title="Edit">
                                                <i class="fa fa-edit"></i> </a>
                                            <?php
                                        } else {
                                            if ($obj->id_jns_evaluasi == '1') {
                                                //echo 'status: '.$status;
                                                //if ($obj->id_status_proses == '1') {
                                                    ?>
                                                    <!--<a href="<?= base_url() . 'backoffice/kelolaproses/accept/' . $obj->id_proses ?>" title="Terima">
                                                        <i class="fa fa-check"></i> </a>
                                                    <a href="<?= base_url() . 'backoffice/kelolaproses/reject/' . $obj->id_proses ?>" title="Tolak">
                                                        <i class="fa fa-remove"></i> </a>-->
                                                <?php //} else {
                                                    ?>
                                                    <a href="<?= base_url() . 'backoffice/kelolaproses/downloadinstrument/' . $obj->id_proses ?>" title="Download Instrument">
                                                        <i class="fa fa-download"></i> </a>
                                                    <a href="<?= base_url() . 'backoffice/kelolaproses/detaildocument/' . $reg->getIdRegistrasi() ?>" title="Daftar Dokumen">
                                                        <i class="fa fa-list-alt"></i> </a>
                                                    <a href="<?= base_url() . 'backoffice/kelolaevaluasi/add/' . $reg->getIdRegistrasi() . '/' . $obj->id_proses; ?>" title="Unggah Hasil">
                                                        <i class="fa fa-upload"></i> </a>
                                                    <?php
                                                //}
                                                ?>

                                                <?php
                                            } else {
                                                if ($obj->type_evaluator == '1') {
                                                    ?>
                                                    <!--<a href="<?= base_url() . 'backoffice/kelolabarang/index/' . $reg->getIdRegistrasi() ?>" 
                                                       title="Data Barang" target="_new">                        
                                                        <i class="fa fa-share"></i> </a>
                                                    <a href="<?= base_url() . 'backoffice/kelolaproses/getdraftberitaacara/' . $reg->getIdRegistrasi() ?>" 
                                                       title="Draft Berita Acara" target="_new">
                                                        <i class="fa fa-file-text"></i>
                                                    </a>-->
                                                    <a href="<?= base_url() . 'backoffice/kelolaproses/getberitaacarafinal/' . $reg->getIdRegistrasi() ?>" 
                                                       title="Berita Acara Final" target="_new">
                                                        <i class="fa fa-file-text-o"></i>
                                                    </a>
                                                    
                                                    <a href="<?= base_url() . 'backoffice/kelolaproses/getpaktakesepakatan/' . $reg->getIdRegistrasi() ?>" 
                                                       title="Format Pakta Kesepakatan" target="_new">
                                                        <i class="fa fa-file-text"></i>
                                                    </a>
                                                    <a href="<?= base_url() . 'backoffice/kelolaproses/detaildocument/' . $reg->getIdRegistrasi() ?>" title="Daftar Dokumen">
                                                        <i class="fa fa-list-alt"></i> </a>
                                                    <a href="<?= base_url() . 'backoffice/kelolaevaluasi/add/' . $reg->getIdRegistrasi() . '/' . $obj->id_proses; ?>" title="Unggah File">
                                                        <i class="fa fa-upload"></i> </a>
                                                    <?php
                                                } else {
                                                    ?>
                                                    <a href="<?= base_url() . 'backoffice/kelolabarang/index/' . $reg->getIdRegistrasi() ?>" 
                                                       title="Data Barang" target="_new">                        
                                                        <i class="fa fa-share"></i> </a>
                                                    <a href="<?= base_url() . 'backoffice/kelolaproses/getpernyataanpersetujuan/' . $reg->getIdRegistrasi() ?>" 
                                                       title="Format Pernyataan Persetujuan" target="_new">
                                                        <i class="fa fa-file-text"></i>
                                                    </a>
                                                    <a href="<?= base_url() . 'backoffice/kelolaproses/getsurattugas/' . $reg->getIdRegistrasi() ?>" 
                                                       title="Format Surat Tugas Penerimaan Barang" target="_new">
                                                        <i class="fa fa-file-text"></i>
                                                    </a>
                                                    <a href="<?= base_url() . 'backoffice/kelolaproses/detaildocument/' . $reg->getIdRegistrasi() ?>" title="Daftar Dokumen">
                                                        <i class="fa fa-list-alt"></i> </a>
                                                    <a href="<?= base_url() . 'backoffice/kelolaevaluasi/add/' . $reg->getIdRegistrasi() . '/' . $obj->id_proses; ?>" title="Unggah File">
                                                        <i class="fa fa-upload"></i> </a>
                                                    <?php
                                                }
                                            }
                                        }
                                        ?>
                                    </td>
                                </tr>
                                <?php
                                $i++;
                            }
                        }
                        ?>        

                    </tbody>
                </table>
            </div>
            <h4>Total Record: <span class="label label-info"><?= $total_row ?></span></h4>
            <div>
                <?php
                echo $this->pagination->create_links();
//echo $articles->count();
                ?>
            </div>

        </div>

    </div>
</div>