<?php

require_once ('Basemodel.php');

//namespace models;
//use models;
/**
 * @author LENOVO
 * @version 1.0
 * @created 27-May-2020 11:20:19 AM
 */
class ItemSubKategori extends CI_Model implements BaseModel {

    private $kdSubKategori;
    private $nmSubKategori;

    function __construct($id = null) {
        parent::__construct();
        if ($id != null) {
            $this->db->select('*');
            $this->db->from('tbl_item_sub2kategori');
            $this->db->where('kd_sub2_kategori', $id);
            $result = $this->db->get();
            if ($result->num_rows() > 0) {
                $row = $result->row();
                $this->kdSubKategori = $row->kd_sub2_kategori;
                $this->nmSubKategori = $row->nm_sub2_kategori;
            }
        }
    }

    function __destruct() {
        
    }

    public function getKdSubKategori() {
        return $this->kdSubKategori;
    }

    public function getNmSubKategori() {
        return $this->nmSubKategori;
    }

    /**
     * 
     * @param newVal
     */
    public function setKdSubKategori($newVal) {
        $this->kdSubKategori = $newVal;
    }

    /**
     * 
     * @param newVal
     */
    public function setNmSubKategori($newVal) {
        $this->nmSubKategori = $newVal;
    }

    public function delete() {
        
    }

    /**
     * 
     * @param row
     * @param segment    segment
     */
    public function get($row = Null, $segment = Null) {
        $this->db->select('*');
        $this->db->from('tbl_item_sub2kategori');

        if ($row == NULL && $segment == NULL) {
            return $this->db->count_all_results();
        } elseif ($row == 0 && $segment == 0) {
            return $this->db->get();
        } else {
            return $this->db->get('', $row, $segment);
        }
    }

    /**
     * 
     * @param field
     * @param value    value
     */
    public function getBy($field, $value) {
        $this->db->select('*');
        $this->db->from('tbl_item_sub2kategori');
        $this->db->where($field, $value);
        $result = $this->db->get();
        if ($result->num_rows() > 0) {
            $row = $result->row();
            $this->kdSubKategori = $row->kd_sub2_kategori;
            $this->nmSubKategori = $row->nm_sub2_kategori;
        }
    }

    /**
     * 
     * @param related
     * @param field
     * @param value    value
     * @param row
     * @param segment
     */
    public function getByRelated($related, $field, $value, $row = Null, $segment = Null) {
        $this->db->select('*');
        $this->db->from('tbl_item_sub2kategori');  
        if($related==''){
            $this->db->where($field, $value);
        }else{
            $this->db->like($related . '.' . $field, $value);
        }
        if ($row == NULL && $segment == NULL) {
            return $this->db->count_all_results();
        } elseif ($row == 0 && $segment == 0) {
            return $this->db->get();
        } else {
            return $this->db->get('', $row, $segment);
        }
    }

    public function insert() {
        
    }

    public function update() {
        
    }

}

?>